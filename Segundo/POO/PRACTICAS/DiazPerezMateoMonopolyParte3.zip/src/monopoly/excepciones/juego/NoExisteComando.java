package monopoly.excepciones.juego;

public class NoExisteComando extends ErrorJuego {
    public NoExisteComando(String message) {
        super(message);
    }
}
