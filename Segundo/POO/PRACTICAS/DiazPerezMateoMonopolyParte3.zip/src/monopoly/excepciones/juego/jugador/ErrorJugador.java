package monopoly.excepciones.juego.jugador;

import monopoly.excepciones.juego.ErrorJuego;

public class ErrorJugador extends ErrorJuego {
    public ErrorJugador(String message) {
        super(message);
    }
}
