package monopoly.excepciones.juego.jugador;

public class NoExisteJugador extends ErrorJugador {
    public NoExisteJugador(String message) {
        super(message);
    }
}
