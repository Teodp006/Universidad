package monopoly.excepciones.juego;

public class NoExisteCasilla extends ErrorJuego {
    public NoExisteCasilla(String message) {
        super(message);
    }
}
