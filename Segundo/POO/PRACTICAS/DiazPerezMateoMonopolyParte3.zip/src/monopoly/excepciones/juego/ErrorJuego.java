package monopoly.excepciones.juego;

public class ErrorJuego extends Exception {
    public ErrorJuego(String message) {
        super(message);
    }
}
