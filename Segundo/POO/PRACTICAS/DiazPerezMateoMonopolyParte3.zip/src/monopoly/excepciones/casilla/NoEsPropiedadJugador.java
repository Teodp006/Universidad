package monopoly.excepciones.casilla;

public class NoEsPropiedadJugador extends ErrorCasilla {
    public NoEsPropiedadJugador(String message) {
        super(message);
    }
}
