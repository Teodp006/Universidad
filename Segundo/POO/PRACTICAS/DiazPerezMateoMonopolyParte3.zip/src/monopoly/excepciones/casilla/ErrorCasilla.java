package monopoly.excepciones.casilla;

public class ErrorCasilla extends Exception {
    public ErrorCasilla(String message) {
        super(message);
    }
}
