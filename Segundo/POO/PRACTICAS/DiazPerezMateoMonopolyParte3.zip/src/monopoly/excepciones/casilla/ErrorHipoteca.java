package monopoly.excepciones.casilla;

public class ErrorHipoteca extends ErrorCasilla {
    public ErrorHipoteca(String message) {
        super(message);
    }
}
