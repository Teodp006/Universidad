package monopoly;

public interface Consola {
    public void imprimir(String mensaje);

    public String leer(String mensaje);
}
