package monopoly;

/** Proyecto realizado por Mateo Díaz Pérez, Pablo Barcia Marcial e Imanol Domínguez Neira */

public class MonopolyETSE {

    public static void main(String[] args) {
        Juego.iniciarPartida("comandos_teo");
    }


}
