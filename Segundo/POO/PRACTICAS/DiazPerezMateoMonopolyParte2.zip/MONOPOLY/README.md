Cambios pendientes para este finde:
  - Resolución de bugs
      - Hipotecar() tiene que permitir que un jugador hipoteque sin estar en esa casilla
      - Pedro paga 14 millones teniendo solo 12, queda con fortuna negativa
  - Cosas que quedan por hacer
      - Bancarrota o hipotecada (cuando tiene menos de 0 dinero).
      - Deshipotecar() al menú
