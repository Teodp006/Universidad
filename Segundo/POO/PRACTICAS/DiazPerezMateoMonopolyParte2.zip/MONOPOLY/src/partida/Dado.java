package partida;
import java.util.Random; //Necesario para incluir la clase random


public class Dado {
    //El dado solo tiene un atributo en nuestro caso: su valor.
    private int valor;

    public Dado(){
    }
    
    //Setters y getters de valor
    public int getValor(){
        return valor;
    }

    public void setValor(int valor){
        if(valor>0 && valor<7) { //El dado tiene valores entre 1 y 6
            this.valor = valor;
        }
    }

    //Metodo para simular lanzamiento de un dado: devolverá un valor aleatorio entre 1 y 6.
    public void hacerTirada(int a) {
        setValor(a);
        System.out.println("Dado: " + valor);
    }

    //Método en el que se genera un número aleatorio del 1 al 6
    public void hacerTirada(){
        Random rnd = new Random();
        setValor(rnd.nextInt(6) + 1); //Ajustamos el valor del dado al siguiente numero generado por rnd, limitado al rango
        System.out.println("Dado: " + valor);
    }

    //Método para verificar si la tirada se considera dobles
    public boolean sonDobles(Dado d2){
        return this.getValor() == d2.getValor();
    }
}

