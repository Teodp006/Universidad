package partida;

import monopoly.*;

import java.util.ArrayList;
import java.util.Random;

import static monopoly.Valor.SUMA_VUELTA;


public class Avatar {

    //Atributos
    private String id; //Identificador: una letra generada aleatoriamente.
    private String tipo; //Sombrero, Esfinge, Pelota, Coche
    private Jugador jugador; //Un jugador al que pertenece ese avatar.
    private Casilla lugar; //Los avatares se sitúan en casillas del tablero.
    //Constructor vacío
    public Avatar() {
    }

    /*Constructor principal. Requiere éstos parámetros:
     * Tipo del avatar, jugador al que pertenece, lugar en el que estará ubicado, y un arraylist con los
     * avatares creados (usado para crear un ID distinto del de los demás avatares).
     */
    public Avatar(String tipo, Jugador jugador, Casilla lugar, ArrayList<Avatar> avCreados) {
        this.jugador = jugador;
        this.lugar = lugar;
        lugar.anhadirAvatar(this);
        this.tipo = tipo;
        if(avCreados == null){
            avCreados = new ArrayList<Avatar>();
        }
        avCreados.add(this);
        generarId(avCreados);
    }

    //Getters y setters

    public String getId() {
        return id;
    }

    public Jugador getJugador() {
        return jugador;
    }

    public String getTipo() {
        return tipo;
    }

    public Casilla getLugar() {
        return lugar;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setJugador(Jugador jugador) {
        this.jugador = jugador;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setLugar(Casilla lugar) {
        this.lugar = lugar;
    }


    //A continuación, tenemos otros métodos útiles para el desarrollo del juego.
    /*Método que permite mover a un avatar a una casilla concreta. Parámetros:
     * - Un array con las casillas del tablero. Se trata de un arrayList de arrayList de casillas (uno por lado).
     * - Un entero que indica el numero de casillas a moverse (será el valor sacado en la tirada de los dados).
     * EN ESTA VERSIÓN SUPONEMOS QUE valorTirada siempre es positivo.
     */
    public void moverAvatar(ArrayList<ArrayList<Casilla>> casillas, int valorTirada) {
        /*Buscamos la localizacion del lugar donde está nuestro Avatar, será un casillas[p1][p2]*/
        // Primero el Lado sur del talbero Casillas[0
        int posicion = this.getLugar().getPosicion();
        Casilla origen = this.getLugar();
        // Eliminanos el avatar de la casilla actual para poder moverlo a la nueva
        origen.getAvatares().remove(this);
        if(posicion+valorTirada >= 40){ // Compruebo que no de una vuelta extra al tablero
            posicion = (posicion + valorTirada) - (Valor.NUM_CASILLAS);
            if (origen.getPosicion() != 40) {
                if (posicion == 0) { // Si nos queda 0 es porque estamos justo en la última casilla del tablero, que es la 40 (la Salida)
                    posicion = 40;
                }
                // Excepto en la primera jugada, que se pasa de Salida (casilla 40) a Solar1 (casilla 1), en todas las demás hay que sumar 200€ al jugador por pasar por Salida
                if (this.getJugador().getVueltas() >= 0) {
                    this.getJugador().sumarFortuna(Valor.SUMA_VUELTA);
                }
                this.getJugador().setVueltas(this.getJugador().getVueltas() + 1);
            }
            else if(this.getJugador().getVueltas() == -1){
                this.getJugador().setVueltas(this.getJugador().getVueltas() + 1);

            }

        }
        else{ //Sino, simplemente sumamos las casilla en la zona que estamos
            posicion += valorTirada;
        }
        // Iteramos todos las Casillas de cada ArrayList hasta llegar a la posicion deseada
        int i = 0;
        Casilla destino = this.buscarCasillaPorPosicion(casillas, posicion);
        // Guardamos el jugador banca para poder saber si la casilla a la que nos movesmos tiene un alquiler o impuesto a pagar
        Jugador banca = casillas.get(3).getLast().getDuenho();
        // Añadimos el avatar a la casilla destino
        destino.getAvatares().add(this);
        destino.sumarvisitada();
        // Ahora mostramos los mensajes correspondientes según la casilla destino
        if(destino.getNombre().equals("IrCarcel")){
            // Si caes en la casilla IrCarcel, automaticamente hay que encarcelar al jugador
            this.getJugador().encarcelar(casillas);
            // ELiminarlo de IrCarcel para que no se duplique
            destino.eliminarAvatar(this);
            // Imprimir un mensaje que indique que el jugador ha sido encarcelado
            System.out.println("El jugador " + this.getJugador().getNombre() + " ha avanzado " + valorTirada + " posiciones desde la casilla " + origen.getNombre() + "hasta la casilla IrCarcel. El avatar se coloca en la casilla de Cárcel");
            return;
        }
        // Mensaje para cuando caes en el Parking, si hay dinero a cobrar lo obtienes y se imprime por pantalla, si no simplemente se dice que te mueves a esa casilla
        else if(destino.getNombre().equals("Parking")){
            System.out.println(
                "El avatar " + this.getId() + " avanza " + valorTirada + " posiciones, desde la casilla " + origen.getNombre() + " hasta la casilla " + destino.getNombre() + ". El jugador " + this.getJugador().getNombre() +
                (destino.getValor() > 0 ? " recibe " + destino.getValor() + "€": " no recibe nada"));
            if(destino.getValor() > 0){
                this.getJugador().sumarFortuna(destino.getValor());
                this.getJugador().sumarpremiosinversionesbote(destino.getValor()); // Si recibe algo de dinero se suma a las inversiones
                destino.setValor(0);
            }
        }
        // Mensaje para las casillas de impuesto, siempre hay que pagarle dinero a la banca y añadirlo al parking
        else if(destino.getTipo().equals("Impuesto")){
            System.out.println("El avatar " + this.getId() + " avanza " + valorTirada + " posiciones, desde la casilla " + origen.getNombre() + " hasta la casilla " + destino.getNombre() + ". El jugador " + this.getJugador().getNombre() +" paga " + destino.getImpuesto() + "€ de impuesto que se depositan en el Parking.");
            if(destino.evaluarCasilla(this.getJugador(), banca, 0)){
                destino.pagarDeudas(banca, this.jugador,valorTirada);
                // La casilla del Parking es la última del lado Oeste
                Casilla parking = casillas.get(1).getLast();
                parking.sumarValor(destino.getImpuesto());
            }
            else{
                // Este es el caso en el que el impuesto supera la fortuna del jugador
                System.out.println("BANCARROTA DE " + this.getJugador().getNombre()); //Hay que programar la bancarrota
            }
        }
        else if(destino.getTipo().equals("Solar") || destino.getTipo().equals("Transporte") || destino.getTipo().equals("Servicios")){
            // Mensaje para las casillas que pueden tener dueño y por tanto alquiler a pagar (Solo si el duenho no es el propio jugador)
            if(!destino.getDuenho().equals(banca) && !destino.getDuenho().equals(this.getJugador())){
                // Si la casilla tiene dueño y se puede pagar el alquiler hay que poner el precio a pagar
                if(!destino.getHipotecada()) {
                    if (destino.evaluarCasilla(this.getJugador(), destino.getDuenho(), 0)) {
                        if (destino.getTipo().equals("Solar")) {
                            System.out.println("El avatar " + this.getId() + " avanza " + valorTirada + " posiciones, desde la casilla " + origen.getNombre() + " hasta la casilla " + destino.getNombre() + ". Se han pagado " + destino.impuestoTotal() + "€ de alquiler al jugador " + destino.getDuenho().getNombre() + ".");
                        } else if (destino.getTipo().equals("Transporte")) {
                            System.out.println("El avatar " + this.getId() + " avanza " + valorTirada + " posiciones, desde la casilla " + origen.getNombre() + " hasta la casilla " + destino.getNombre() + ". Se han pagado " + destino.contarCasillas(destino.getDuenho(), "Transporte") * destino.impuestoTotal() + "€ de alquiler al jugador " + destino.getDuenho().getNombre() + ".");
                        } else if (destino.getTipo().equals("Servicios")) {
                            if (destino.contarCasillas(destino.getDuenho(), "Servicios") == 1) {
                                System.out.println("El avatar " + this.getId() + " avanza " + valorTirada + " posiciones, desde la casilla " + origen.getNombre() + " hasta la casilla " + destino.getNombre() + ". Se han pagado " + (valorTirada * 4) * destino.impuestoTotal() + "€ de alquiler al jugador " + destino.getDuenho().getNombre() + ".");
                            } else {
                                System.out.println("El avatar " + this.getId() + " avanza " + valorTirada + " posiciones, desde la casilla " + origen.getNombre() + " hasta la casilla " + destino.getNombre() + ". Se han pagado " + (valorTirada * 10) * destino.impuestoTotal() + "€ de alquiler al jugador " + destino.getDuenho().getNombre() + ".");
                            }
                        }
                        destino.pagarDeudas(destino.getDuenho(), this.jugador, valorTirada);
                    }
                    // Si no se puede pagar el alquiler hay que indicar que el jugador cae en bancarrota
                    else {
                        System.out.println("El avatar " + this.getId() + " avanza " + valorTirada + " posiciones, desde la casilla" + this.getJugador().getNombre() + " hasta la casilla " + destino.getNombre() + ". Se han intentado pagar " + destino.impuestoTotal() + "€ de alquiler al jugador " + destino.getDuenho().getNombre() + ", pero el jugador no tiene suficiente dinero. " + this.getJugador() + " cae en Bancarrota."); //Hay que programar la bancarrota
                    }
                }
                else{
                    // Mensaje en caso de que la casilla esté hipotecada
                    System.out.println("El avatar " + this.getId() + " avanza " + valorTirada + " posiciones, desde la casilla " + origen.getNombre() + " hasta la casilla " + destino.getNombre() + ". La casilla está hipotecada, por lo que no se paga alquiler.");
                }
            }
            // Mensaje para las casillas que no tienen dueño (la banca) o que el dueño es el propio jugador
            else if(destino.getDuenho().equals(banca)){
                System.out.println("El avatar " + this.getId() + " avanza " + valorTirada + " posiciones, desde la casilla " + origen.getNombre() + " hasta la casilla " + destino.getNombre() + ".");
            }
        }
        // Mensaje predeterminado para casillas con acciones sin programar por ahora como Suerte y Comunidad
        else{
            System.out.println("El avatar " + this.getId() + " avanza " + valorTirada + " posiciones, desde la casilla " + origen.getNombre() + " hasta la casilla " + destino.getNombre() + ".");
        }
        // Colocamos al avatar en la casilla destino y aumentamos el contador de veces que ha sido visitada
        this.setLugar(destino);
    }

    /*Método que permite generar un ID para un avatar. Sólo lo usamos en esta clase (por ello es privado).
     * El ID generado será una letra mayúscula. Parámetros:
     * - Un arraylist de los avatares ya creados, con el objetivo de evitar que se generen dos ID iguales.
     */
    private void generarId(ArrayList<Avatar> avCreados) {
        char i;
        Random rnd = new Random();
        //creamos un bucle do-while para generar un id aleatorio que no exista ya en el array de avatares creados
        do {
            i = (char)('A' + rnd.nextInt(26)); //Genera números desde 65 hasta 90

        } while (existeId(avCreados, i));
        //convertimos el valor char a String y lo asignamos al id del avatar
        avCreados.getLast().setId(String.valueOf(i));
        System.out.println("Id del Avatar: " + getId());
    }


    /*Método auxiliar para comprobar si un Id se encuentra en el Array de Avatares*/
    private boolean existeId(ArrayList<Avatar> avCreados, char i) {
        // Si hay más de un avatar creado, comprobamos si el id generado ya existe en alguno de ellos con un bucle for each
        if(avCreados.size()>1) {
            for (Avatar av : avCreados) {
                if (av != avCreados.getLast() && av.getId().equals(String.valueOf(i))) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    //sobreescribimos el metodo toString para que devuelva el id del avatar
    public String toString(){
        return id;
    }

    private Casilla buscarCasillaPorPosicion(ArrayList<ArrayList<Casilla>> casillas, int posiciondestino){
        int i = 0;
        Casilla destino;
        for(ArrayList<Casilla> lado : casillas) {
            for (Casilla casilla : lado) {
                i++;
                if (i == posiciondestino) {
                    destino = casilla;
                    return destino;
                }
            }
        }
        return null;
    }



}


