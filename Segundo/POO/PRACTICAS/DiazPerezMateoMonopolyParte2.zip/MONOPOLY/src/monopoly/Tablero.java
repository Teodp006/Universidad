package monopoly;

import partida.*;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;


public class Tablero {
    //Atributos.
    private ArrayList<ArrayList<Casilla>> posiciones; //Posiciones del tablero: se define como un arraylist de arraylists de casillas (uno por cada lado del tablero).
    private HashMap<String, Grupo> grupos; //Grupos del tablero, almacenados como un HashMap con clave String (será el color del grupo).
    private Jugador banca; //Un jugador que será la banca.

    //Constructor: únicamente le pasamos el jugador banca (que se creará desde el menú).
    public Tablero(Jugador banca) {
        this.banca = banca;
        this.banca.setNombre("banca");
        this.posiciones = new ArrayList<>();
        this.grupos = new HashMap<>();
        this.generarCasillas();
    }

    //Setters y Getters
    public ArrayList<ArrayList<Casilla>> getPosiciones() {
        return posiciones;
    }

    public HashMap<String, Grupo> getGrupos() {
        return grupos;
    }

    public Jugador getBanca() {
        return banca;
    }

    public void setBanca(Jugador banca) {
        this.banca = banca;
    }

    public void setPosiciones(ArrayList<ArrayList<Casilla>> posiciones) {
        this.posiciones = posiciones;
    }

    public void setGrupos(HashMap<String, Grupo> grupos) {
        this.grupos = grupos;
    }


    //Método para crear todas las casillas del tablero. Formado a su vez por cuatro métodos (1/lado).
    private void generarCasillas() { //COMPROBAR VALORES
        this.insertarLadoSur();
        this.insertarLadoOeste();
        this.insertarLadoNorte();
        this.insertarLadoEste();
    }

    //Método para asignar el grupo a las casillas
    private void asignarGrupo(String color) {
        // recorre las casillas de un grupo asignandoles el color de su propio grupo a cada una de ellas
        for (Casilla c : this.grupos.get(color).getMiembros()) {
            c.setGrupo(this.grupos.get(color));
        }
    }

    //Método para insertar las casillas del lado norte.
    private void insertarLadoNorte() {
        //crea el arraylist de casillas del lado norte e inserta las casillas correspondientes con sus atributos correspondientes
        ArrayList<Casilla> norte = new ArrayList<>();
        norte.add(new Casilla("Solar12", "Solar", 21, 2200000, banca));
        norte.get(0).setImpuesto(180000);
        norte.get(0).ajustarAlquileres(2200000, 10500000, 2100000, 2100000);
        norte.add(new Casilla("Suerte", "Suerte", 22, 0, banca));
        norte.add(new Casilla("Solar13", "Solar", 23, 2200000, banca));
        norte.get(2).setImpuesto(180000);
        norte.get(2).ajustarAlquileres(2200000, 10500000, 2100000, 2100000);
        norte.add(new Casilla("Solar14", "Solar", 24, 2400000, banca));
        norte.get(3).setImpuesto(200000);
        norte.get(3).ajustarAlquileres(2325000, 11000000, 2200000, 2200000);
        norte.add(new Casilla("Trans3", "Transporte", 25, 500000, banca));
        norte.get(4).setImpuesto(250000);
        norte.add(new Casilla("Solar15", "Solar", 26, 2600000, banca));
        norte.get(5).setImpuesto(220000);
        norte.get(5).ajustarAlquileres(2450000, 11500000, 2300000, 2300000);
        norte.add(new Casilla("Solar16", "Solar", 27, 2600000, banca));
        norte.get(6).setImpuesto(220000);
        norte.get(6).ajustarAlquileres(2450000, 11500000, 2300000, 2300000);
        norte.add(new Casilla("Serv2", "Servicios", 28, 500000, banca));
        norte.get(7).setImpuesto(50000);
        norte.add(new Casilla("Solar17", "Solar", 29, 2800000, banca));
        norte.get(8).setImpuesto(240000);
        norte.get(8).ajustarAlquileres(2600000, 12000000, 2400000, 2400000);
        // inserta dentro del hashmap grupos los diferentes grupos con sus casillas correspondientes
        this.grupos.put("Rojo", new Grupo(norte.get(0), norte.get(2), norte.get(3), "ROJO"));
        asignarGrupo("Rojo");
        this.grupos.put("Amarillo", new Grupo(norte.get(5), norte.get(6), norte.get(8), "AMARILLO"));
        asignarGrupo("Amarillo");
        //por ultimo añade al arraylist de los arraylist de casillas el arraylist q posee el total de casillas del lado norte
        posiciones.add(2, norte);
        //la posicion 2 porque el lado sur ya está en la posicion 0 y el oeste en la posicion 1
    }

    //Método para insertar las casillas del lado sur.
    private void insertarLadoSur() {
        // declara y crea el arraylist de casillas del lado sur e inserta las casillas correspondientes con sus atributos correspondientes
        ArrayList<Casilla> sur = new ArrayList<>();
        sur.add(new Casilla("Solar1", "Solar", 1, 600000, banca));
        sur.get(0).setImpuesto(20000);
        sur.get(0).ajustarAlquileres(400000, 2500000,50000,50000);
        sur.add(new Casilla("Caja", "Comunidad", 2, 0, banca));
        sur.add(new Casilla("Solar2", "Solar", 3, 600000, banca));
        sur.get(2).ajustarAlquileres(400000, 4500000, 900000, 900000);
        sur.get(2).setImpuesto(40000);
        sur.add(new Casilla("Imp1", 4, 2000000, banca));
        sur.add(new Casilla("Trans1", "Transporte", 5, 500000, banca));
        sur.get(4).setImpuesto(250000);
        sur.add(new Casilla("Solar3", "Solar", 6, 1000000, banca));
        sur.get(5).setImpuesto(60000);
        sur.get(5).ajustarAlquileres(1000000, 5500000,1100000,1100000);
        sur.add(new Casilla("Suerte", "Suerte", 7, 0, banca));
        sur.add(new Casilla("Solar4", "Solar", 8, 1000000, banca));
        sur.get(7).setImpuesto(60000);
        sur.get(7).ajustarAlquileres(1000000, 5500000,1100000,1100000);
        sur.add(new Casilla("Solar5", "Solar", 9, 1200000, banca));
        sur.get(8).setImpuesto(80000);
        sur.get(8).ajustarAlquileres(1250000, 6000000,1200000,1200000);

        // se inserta dentro del hashmap grupos los diferentes grupos con sus casillas correspondientes y se le asigna el grupo a cada casilla
        this.grupos.put("Marron", new Grupo(sur.get(0), sur.get(2), "MARRON"));
        asignarGrupo("Marron");
        this.grupos.put("Cyan", new Grupo(sur.get(5), sur.get(7), sur.get(8), "CYAN"));
        asignarGrupo("Cyan");
        //por ultimo añade al arraylist de los arraylist de casillas el arraylist q posee el total de casillas del lado sur en la primera posicion
        posiciones.addFirst(sur);
    }


    //Método que inserta casillas del lado oeste.
    private void insertarLadoOeste() {
        ArrayList<Casilla> oeste = new ArrayList<>();
        // inserta las casillas que se ubicaran en el oeste de nuestro tablero con sus atributos correspondientes
        oeste.add(new Casilla("Carcel", "Especial", 10, 0, banca));
        oeste.add(new Casilla("Solar6", "Solar", 11, 1400000, banca));
        oeste.get(1).setImpuesto(100000);
        oeste.get(1).ajustarAlquileres(1500000, 7500000,1500000,1500000);
        oeste.add(new Casilla("Serv1", "Servicios", 12, 500000, banca));
        oeste.get(2).setImpuesto(50000);
        oeste.add(new Casilla("Solar7", "Solar", 13, 1400000, banca));
        oeste.get(3).setImpuesto(100000);
        oeste.get(3).ajustarAlquileres(1500000, 7500000,1500000,1500000);
        oeste.add(new Casilla("Solar8", "Solar", 14, 1600000, banca));
        oeste.get(4).setImpuesto(120000);
        oeste.get(4).ajustarAlquileres(1750000, 9000000,1800000,1800000);
        oeste.add(new Casilla("Trans2", "Transporte", 15, 500000, banca));
        oeste.get(5).setImpuesto(250000);
        oeste.add(new Casilla("Solar9", "Solar", 16, 1800000, banca));
        oeste.get(6).setImpuesto(140000);
        oeste.get(6).ajustarAlquileres(1850000, 9500000,1900000,1900000);
        oeste.add(new Casilla("Caja", "Comunidad", 17, 0, banca));
        oeste.add(new Casilla("Solar10", "Solar", 18, 1800000, banca));
        oeste.get(8).setImpuesto(140000);
        oeste.get(8).ajustarAlquileres(1850000, 9500000,1900000,1900000);
        oeste.add(new Casilla("Solar11", "Solar", 19, 2200000, banca));
        oeste.get(9).setImpuesto(160000);
        oeste.get(9).ajustarAlquileres(2000000, 10000000,2000000,2000000);
        oeste.add(new Casilla("Parking", "Especial", 20, 0, banca));
        //insertamos los diferentes grupos con sus casillas correspondientes en el hashmap grupos asignandto tmb cada color de grupo a sus casillas correspondientes
        this.grupos.put("Rosa", new Grupo(oeste.get(1), oeste.get(3), oeste.get(4), "ROSA"));
        asignarGrupo("Rosa");
        this.grupos.put("Salmon", new Grupo(oeste.get(6), oeste.get(8), oeste.get(9), "SALMON"));
        asignarGrupo("Salmon");
        //por ultimo insertamos el lado oeste en el arraylist de arraylists de casillas en la posicion 1
        posiciones.add(1, oeste);
    }


    //Método que inserta las casillas del lado este.
    private void insertarLadoEste() {
        ArrayList<Casilla> este = new ArrayList<>();
        //insertamos las casillas dentro de su grupo correspondientes con sus atributos ya establecidos
        este.add(new Casilla("IrCarcel", "Especial", 30, 0, banca));
        este.add(new Casilla("Solar18", "Solar", 31, 3000000, banca));
        este.get(1).setImpuesto(260000);
        este.get(1).ajustarAlquileres(2750000, 12750000, 2550000, 2550000);
        este.add(new Casilla("Solar19", "Solar", 32, 3000000, banca));
        este.get(2).setImpuesto(260000);
        este.get(2).ajustarAlquileres(2750000, 12750000, 2550000, 2550000);
        este.add(new Casilla("Caja", "Comunidad", 33, 0, banca));
        este.add(new Casilla("Solar20", "Solar", 34, 3200000, banca));
        este.get(4).setImpuesto(280000);
        este.get(4).ajustarAlquileres(3000000, 14000000, 2800000, 2800000);
        este.add(new Casilla("Trans4", "Transporte", 35, 500000, banca));
        este.get(5).setImpuesto(250000);
        este.add(new Casilla("Suerte", "Suerte", 36, 0, banca));
        este.add(new Casilla("Solar21", "Solar", 37, 3500000, banca));
        este.get(7).setImpuesto(350000);
        este.get(7).ajustarAlquileres(3250000, 17000000, 3400000, 3400000);
        este.add(new Casilla("Imp2", 38, 2000000, banca));
        este.add(new Casilla("Solar22", "Solar", 39, 4000000, banca));
        este.get(9).setImpuesto(500000);
        este.get(9).ajustarAlquileres(4250000, 20000000, 4000000, 4000000);
        este.add(new Casilla("Salida", "Especial", 40, 0, banca));
        // insertamos los diferentes grupos con sus casillas correspondientes en el hashmap grupos asignando tmb cada color de grupo a sus casillas correspondientes
        this.grupos.put("Verde", new Grupo(este.get(1), este.get(2), este.get(4), "VERDE"));
        asignarGrupo("Verde");
        this.grupos.put("Azul", new Grupo(este.get(7), este.get(9), "AZUL"));
        asignarGrupo("Azul");
        //por ultimo añade al arraylist de los arraylist de casillas el arraylist q posee el total de casillas del lado este en la posicion 3
        posiciones.add(3, este);
    }

    //Método para imprimir el tablero por consola:
    @Override
    public String toString() {
        String tablero = "";
        tablero = tablero.concat("\n");
        // Imprimos |nombre| con Súperlineado y Subrayado de la última casilla del lado oeste (Parking)
        tablero = tablero.concat("|" + Valor.UNDER_OVER + this.colorearCasilla(this.getParking()) + "|" + Valor.RESET);


        // Vamos a imprimir todas las casillas del lado norte (Solar12-Solar17)
        for (Casilla casilla : getLado("NORTE")) {
            // Imprimimos |nombre| de cada casilla del lado norte con subrayado y superlineado
            tablero = tablero.concat(Valor.UNDER_OVER + this.colorearCasilla(casilla) + "|" + Valor.RESET);
        }

        // Imprimimos |nombre| con el estilo anterior de la primera casilla del lado este (IrCarcel)
        tablero = tablero.concat(Valor.UNDER_OVER + this.colorearCasilla(this.getIrCarcel()) + "|\n");

        // Iteramos desde la penúltima hasta la segunda casilla del lado OESTE, intercalando espacios y casillas del lado ESTE
        for (int i = 1; i < (this.getLado("OESTE").size()) - 1; i++) {
            // Se imprime |nombre| de cada casilla del lado OESTE (desde la penúltima hasta la segunda)
            tablero = tablero.concat("|" + Valor.UNDERLINE + this.colorearCasilla(this.getLado("OESTE").get((this.getLado("OESTE").size()) - i - 1)) + "|");

            // Se calculan los espacios en blanco para cubrir cada casilla del Norte o del Sur, para que sea cuadrado deben tener el mismo tamaño ya que hay las misma casillas en el Norte y en Sur
            int maximo = (MaxAnchuraCasilla(getLado("NORTE")) > MaxAnchuraCasilla(getLado("SUR"))) ? MaxAnchuraCasilla(getLado("NORTE")) : MaxAnchuraCasilla(getLado("SUR"));

            // Imprimimos tantos espacios como número de casillas
            for (int j = 0; j < getLado("NORTE").size() * maximo + Valor.NUM_BARRAS; j++) {
                tablero = tablero.concat(" ");
            }

            // Se imprime |nombre| de la casilla complementaria del lado ESTE (vamos desde la segunda hasta la penúltima)
            tablero = tablero.concat("|" + Valor.UNDERLINE + this.colorearCasilla(this.getLado("ESTE").get(i)) + "|\n");
        }

        //Imprimimos |nombre| de la primera casilla del lado OESTE (la Carcel)
        tablero = tablero.concat("|" + Valor.UNDERLINE + this.colorearCasilla(this.getCarcel()) + "|");

        //Se imprime |nombre| de las casilla del lado SUR en orden inverso (Solar1-Solar5)
        for (int i = this.getLado("SUR").size() - 1; i >= 0; i--) {
            Casilla casilla = this.getLado("SUR").get(i);
            tablero = tablero.concat(Valor.UNDER_OVER + this.colorearCasilla(casilla) + "|");
        }

        //Se imprime |nombre| de la última casilla del lado ESTE (la Salida)
        tablero = tablero.concat(Valor.UNDERLINE + this.colorearCasilla(this.getInicio()) + "|\n");
        return tablero;
    }

    //Reescritura del método equals para determinar que 2 tableros son iguales si tienen la mismas posiciones, grupos y banca
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Tablero tablero = (Tablero) obj;
        return posiciones.equals(tablero.posiciones) && grupos.equals(tablero.grupos) && banca.equals(tablero.banca);
    }

    //Método que busca una casilla por su nombre
    public Casilla buscarCasilla(String nombre) {
        for (ArrayList<Casilla> lado : posiciones) { //Recorremos todos los lados
            for (Casilla casilla : lado) { //Recorremos todas las casillas de cada lado
                if (casilla.getNombre().equals(nombre)) {
                    return casilla;
                }
            }
        }
        return null;
    }


    // Método auxiliar para obtener un lado del tablero por su nombre
    public ArrayList<Casilla> getLado(String lado) {
        //se retorna el arraylist de casillas correspondiente al lado solicitado
        return switch (lado) {
            case "NORTE" -> posiciones.get(2);
            case "SUR" -> posiciones.get(0);
            case "OESTE" -> posiciones.get(1);
            case "ESTE" -> posiciones.get(3);
            default -> null;
        };
    }

    // Método auxiliar para obtener las casillas de las esquinas
    public Casilla getIrCarcel() {
        return this.getLado("ESTE").get(0); //La casilla de ir carcel está en el lado este, en la posición 0.
    }

    public Casilla getInicio() {
        return this.getLado("ESTE").get(10); //La casilla de salida está en el lado este, en la posición 10 (empezando a contar desde 0).
    }

    public Casilla getCarcel() {
        return this.getLado("OESTE").get(0); //La casilla de la cárcel está en el lado oeste, en la posición 0.
    }

    public Casilla getParking() {
        return this.getLado("OESTE").get(10); //La casilla del parking está en el lado oeste, en la posición 10.
    }


    // Método para colorear todo el texto que se muestra en una casilla.
    // EJ: ───────  <- Esto en negro/color casilla superior
    //    |Solar12 &M| <- Todo esto coloreado
    //    ───────── <- Todo esto coloreado
    public String colorearCasilla(Casilla casilla) {
        if (casilla.getGrupo() != null) {
            switch (casilla.getGrupo().getColorGrupo()) {
                case "MARRON":
                    return Valor.BLACK + casilla.getNombre() + generateSpaces(casilla) + mostrarPlayers(casilla) + Valor.RESET;
                case "CYAN":
                    return Valor.CYAN + casilla.getNombre() + generateSpaces(casilla) + mostrarPlayers(casilla) + Valor.RESET;
                case "ROSA":
                    return Valor.PURPLE + casilla.getNombre() + generateSpaces(casilla) + mostrarPlayers(casilla) + Valor.RESET;
                case "SALMON":
                    return Valor.ORANGE + casilla.getNombre() + generateSpaces(casilla) + mostrarPlayers(casilla) + Valor.RESET;
                case "ROJO":
                    return Valor.RED + casilla.getNombre() + generateSpaces(casilla) + mostrarPlayers(casilla) + Valor.RESET;
                case "AMARILLO":
                    return Valor.YELLOW + casilla.getNombre() + generateSpaces(casilla) + mostrarPlayers(casilla) + Valor.RESET;
                case "VERDE":
                    return Valor.GREEN + casilla.getNombre() + generateSpaces(casilla) + mostrarPlayers(casilla) + Valor.RESET;
                case "AZUL":
                    return Valor.BLUE + casilla.getNombre() + generateSpaces(casilla) + mostrarPlayers(casilla) + Valor.RESET;
            }
        }
        return casilla.getNombre() + generateSpaces(casilla) + mostrarPlayers(casilla) + Valor.RESET;
    }


    // Método para imprimir los ids de los jugadores que hay en una casilla
    // Formato &P1P2P3... con Pn el ID del jugador n, Ej: &FM o &Q
    public String mostrarPlayers(Casilla casilla) {
        String fichas = "";
        if (casilla.getAvatares() != null && !casilla.getAvatares().isEmpty()) {
            //Podemos el espacio para separar el nombre de la casilla y los id de los jugadores " &P1P2"
            fichas = " &";
            for (Avatar avatar : casilla.getAvatares()) {
                fichas = fichas.concat(avatar.getId());
            }
        }
        return fichas;
    }

    //  Método que devuelve la anchura máxima de cada casilla de un lado del tablero, para que todas sean del mismo tamaño
    public int MaxAnchuraCasilla(ArrayList<Casilla> lado) {
        int max = 0;
        for (Casilla casilla : lado) {
            // Medimos cuando ocupa "nombrecasilla &P1P2P3
            int aux = casilla.getNombre().length() + (mostrarPlayers(casilla).length());
            if (aux > max) {
                max = aux;
            }
        }
        return max;
    }

    // Método para calcular la cantidad de espacios entre el final del nombre de la casilla y el "|" o el " &Ids" para que esa casilla
    // llegue a ocuapar el MaxAnchura de esa casilla.
    public String generateSpaces(Casilla casilla) {
        // Comprobamos en que lado está la casilla
        String mensaje = "";
        if (this.getLado("NORTE").contains(casilla) || this.getLado("SUR").contains(casilla)) { //NORTE
            // El lado norte y sur van a tener que tener las mismas proporciones para que el tablero sea cuadrado, así que tomamos el máximo entre ambos lados
            ArrayList<Casilla> lado = (MaxAnchuraCasilla(getLado("NORTE")) > MaxAnchuraCasilla(getLado("SUR"))) ? getLado("NORTE") : getLado("SUR");
            // Comprobamos que no llegue ya al máximo con nombre &Ids
            if (MaxAnchuraCasilla(lado) - (casilla.getNombre().concat(mostrarPlayers(casilla))).length() <= 0) {
                return mensaje;
            }
            // Si no llega al máximo, añadimos los espacios que faltan hasta llegar al máximo
            else {
                for (int i = (casilla.getNombre().concat(mostrarPlayers(casilla))).length(); i < MaxAnchuraCasilla(lado); i++) {
                    mensaje = mensaje.concat(" ");
                }
                return mensaje;
            }
        }
        // Si la casilla está en lado OESTE tendrá la proporción del lado OESTE
        else if (this.getLado("OESTE").contains(casilla)) {
            // Comprobamos que no llegue ya al máximo con nombre &Ids
            if (MaxAnchuraCasilla(getLado("OESTE")) - (casilla.getNombre().concat(mostrarPlayers(casilla))).length() <= 0) {
                return mensaje;
            }
            // Si no llega al máximo, añadimos los espacios que faltan hasta llegar al máximo del lado OESTE
            else {
                for (int i = (casilla.getNombre().concat(mostrarPlayers(casilla))).length(); i < MaxAnchuraCasilla(getLado("OESTE")); i++) {
                    mensaje = mensaje.concat(" ");
                }
                return mensaje;
            }
        }
        // Si la casilla está en lado ESTE tendrá la proporción del lado ESTE
        else if (this.getLado("ESTE").contains(casilla)) {
            // Comprobamos que no llegue al máximo con nombre &Ids
            if (MaxAnchuraCasilla(getLado("ESTE")) - (casilla.getNombre().concat(mostrarPlayers(casilla))).length() <= 0) {
                return mensaje;
            }
            // Si no llega al máximo , añadimos los espacios que faltan hasta llegar al máximo del lado ESTE
            else {
                for (int i = (casilla.getNombre().concat(mostrarPlayers(casilla))).length(); i < MaxAnchuraCasilla(getLado("ESTE")); i++) {
                    mensaje = mensaje.concat(" ");
                }
                return mensaje;
            }
        }
        else { // Posible caso de error, si la casilla no perteneciese a ningún lado se retornará null
            return null;
        }
    }

    //Método para obtener todas las propiedades que son de la banca
    public ArrayList<Casilla> propiedadesBanca() {
        ArrayList<Casilla> propiedades = new ArrayList<>(); //Lista para almacenar las propiedades de la banca
        for (ArrayList<Casilla> lado : posiciones) { //Recorremos todos los lados
            for (Casilla casilla : lado) { //Y todas las casillas de cada lado
                //Si el dueño es la banca y es una casilla que se puede comprar entonces se añade a las propiedades de la banca
                if (casilla.getDuenho() == this.banca && (casilla.getTipo().equals("Solar") || casilla.getTipo().equals("Transporte") || casilla.getTipo().equals("Servicios"))) {
                    propiedades.add(casilla);
                }
            }
        }
        return propiedades;
    }

    //Metodo que cuenta el numero de edificios de un tipo concreto en el tablero
    public int contarEdificiosTipo(String tipo){
        int numEdificios=0;
        for(ArrayList<Casilla> lado: posiciones){
            for(Casilla casilla: lado){
                numEdificios += casilla.numTipo(tipo);
            }
        }
        return numEdificios;
    }

    //Metodo que incrementa el valor de todas las casillas solares del tablero (trás 4 vueltas)
    public void incrementarValorSolares(){
        for(ArrayList<Casilla> lado: posiciones){
            for(Casilla casilla: lado){
                if(casilla.getTipo().equals("Solar")){
                    casilla.sumarValor(casilla.getValor());
                }
            }
        }
    }

}


