package monopoly;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import partida.*;

import static monopoly.Valor.*;

public class Menu {

    //Atributos
    private ArrayList<Jugador> jugadores; //Jugadores de la partida.
    private ArrayList<Avatar> avatares; //Avatares en la partida.
    private int turno = 0; //Índice correspondiente a la posición en el arrayList del jugador (y el avatar) que tienen el turno
    private int lanzamientos; //Variable para contar el número de lanzamientos de un jugador en un turno.
    private Tablero tablero; //Tablero en el que se juega.
    private Dado dado1; //Dos dados para lanzar y avanzar casillas.
    private Dado dado2;
    private Jugador banca; //El jugador banca.
    private boolean tirado; //Booleano para comprobar si el jugador que tiene el turno ha tirado o no.
    private boolean solvente; //Booleano para comprobar si el jugador que tiene el turno es solvente, es decir, si ha pagado sus deudas.
    private int suerte = 1;
    private int comunidad = 1;
    private int incrementoSolares=0;

    //Constructor
    public Menu(ArrayList<String> listaComandos) {
        iniciarPartida();
        for (String comando : listaComandos) {
            analizarComando(comando);
        }
    }

    // Método para inciar una partida: crea los jugadores y avatares.
    private void iniciarPartida() {
        jugadores = new ArrayList<Jugador>();
        this.banca = new Jugador();
        tablero = new Tablero(this.banca);
        this.banca.setFortuna(FORTUNA_BANCA);
        this.banca.setPropiedades(this.tablero.propiedadesBanca());
        avatares = new ArrayList<Avatar>();
        dado1 = new Dado();
        dado2 = new Dado();
        tirado = false;
        solvente = true;
        lanzamientos = 0;
    }

    // setters y getters
    private ArrayList<Jugador> getJugadores() {
        return jugadores;
    }

    private ArrayList<Avatar> getAvatares() {
        return avatares;
    }

    private int getTurno() {
        return turno;
    }

    private int getLanzamientos() {
        return lanzamientos;
    }

    public Tablero getTablero() {
        return tablero;
    }

    private Dado getDado1() {
        return dado1;
    }

    private Dado getDado2() {
        return dado2;
    }

    private Jugador getBanca() {
        return banca;
    }

    private boolean getTirado() {
        return tirado;
    }

    private boolean getSolvente() {
        return solvente;
    }

    private void setJugadores(ArrayList<Jugador> jugadores) {
        this.jugadores = jugadores;
    }

    private void setAvatares(ArrayList<Avatar> avatares) {
        this.avatares = avatares;
    }

    private void setTurno(int turno) {
        this.turno = turno;
    }

    private void setLanzamientos(int lanzamientos) {
        this.lanzamientos = lanzamientos;
    }

    private void setTablero(Tablero tablero) {
        this.tablero = tablero;
    }

    private void setDado1(Dado dado1) {
        this.dado1 = dado1;
    }

    private void setDado2(Dado dado2) {
        this.dado2 = dado2;
    }

    private void setBanca(Jugador banca) {
        this.banca = banca;
    }

    private void setTirado(boolean tirado) {
        this.tirado = tirado;
    }

    private void setSolvente(boolean solvente) {
        this.solvente = solvente;
    }

    // Fin setters y getters
    /*Método que interpreta el comando introducido y toma la accion correspondiente.
     * Parámetro: cadena de caracteres (el comando).
     */
    public void analizarComando(String comando) {
        System.out.println(">>> " + comando);
        //partimos el string del comando entero en sus diferentes componentes
        String[] partes = comando.split(" ");
        //distinguimos mediante el switch entre los diferentes comandos existentes.
        switch (partes[0]) {
            case "crear":
                //distinguimos los diferentes casos del comando crear
                switch (partes[1]) {
                    case "jugador":
                        //verificamos q el numero de jugadores es menor al numero maximo del juego
                        if (jugadores.size() >= 4) {
                            System.out.println("No se pueden crear más jugadores. El número máximo es 4.\n");
                            return;
                        }
                        // recorremos la lista de jugaodres para revisar q no tengamos el mismo nombre ya guardado
                        for (Jugador jugador : jugadores) {
                            if (jugador.getNombre().equals(partes[2])) {
                                System.out.println("El nombre de jugador " + partes[2] + " ya está en uso. Elija otro.\n");
                                return;
                            }
                        }
                        // comprobamos q la figura pertenezca a las disponibles y q no esta ya escogida
                        if (partes[3].equals("coche") || partes[3].equals("pelota") || partes[3].equals("sombrero") || partes[3].equals("esfinge")) {
                            for (Jugador jugador : jugadores) {
                                if (jugador.getAvatar().getTipo().equals(partes[3])) {
                                    System.out.println("La figura " + jugador.getAvatar().getTipo() + " ya esta en uso. Elija otro\n");
                                    return;
                                }
                            }
                            Jugador jugador = new Jugador(partes[2], partes[3], tablero.getInicio(), avatares);
                            jugadores.add(jugador);
                        } else {
                            System.out.println("El avatar " + partes[3] + " no existe. Los avatares disponibles son: coche, pelota, sombrero y esfinge.\n");
                            return;
                        }
                        break;
                }
                break;

            case "jugador":
                //llamamos al metodo q nos da el jugador que tiene el turno actualmente
                descJugador(comando);
                break;

            case "listar":
                //diferenciamos entre los diferentes casos del comando listar
                switch (partes[1]) {
                    case "jugadores":
                        //llamamos al metodo q lista los jugadores
                        listarJugadores();
                        break;
                    case "enventa":
                        //llamamos al metodo q lista las casillas en venta
                        listarVenta();
                        break;
                    case "edificios":
                        if (partes.length == 3) {
                            //llamamos al metodo q lista los edificios de un grupo en concreto
                            listarEdificiosGrupo(partes[2]);
                        } else {
                            //llamamos al metodo q lista los edificios
                            listarEdificios();
                        }
                        break;
                }
                break;
            case "lanzar":
                //comprobamos si el comando es lanzar dados
                //si el comando tiene 3 partes se han forzado los dados
                if (!tirado && partes.length == 3) {
                    try {
                        String[] partes2 = partes[2].split("\\+");
                        lanzarDadosForzados(Integer.parseInt(partes2[0]), Integer.parseInt(partes2[1]));
                        // llamamos al metodo para comprobar si ha caido en una casilla de suerte o comunidad
                        suerte_comunidad();
                    } catch (NumberFormatException e) {
                        System.out.println("Error en el formato de los dados. Deben ser números enteros separados por '+'.\n");
                        tirado = false;
                    }
                }
                //si el comando tiene 2 partes se lanzan los dados obteniendo numeros aleatorios
                else if (!tirado && partes.length == 2) {
                    if (partes[1].equals("dados")) {
                        lanzarDados();
                        // llamamos al metodo para comprobar si ha caido en una casilla de suerte o comunidad
                        suerte_comunidad();
                    }
                }
                // comprobamos si el jugador esta en la carcel y si no ha tirado aun para q pueda lanzar los dados para intentar salir sin pagar

                else {
                    System.out.println("El jugador " + jugadores.get(turno).getNombre() + " ya ha tirado los dados este turno.\n");
                }
                //printeamos el tablero para comprobar como han quedado las posiciones de los jugadores tras la tirada
                System.out.println(tablero);
                break;

            case "acabar":
                //distinguimos si el comando es acabar turno y llamamos al metodo correspondiente
                acabarTurno();
                //printeamos el jugador que tiene el turno ahora
                System.out.println("El jugador actual es " + jugadores.get(turno).getNombre() + ".\n");
                break;
            case "salir":
                //comprobamos si el comando es salir carcel y llamamos al metodo correspondiente en caso de que nuestro jugador este en la carcel
                if (jugadores.get(turno).getenCarcel()) {
                    salirCarcel();
                } else {
                    System.out.println("El jugador " + jugadores.get(turno).getNombre() + " no está en la carcel.\n");
                }
                break;
            case "describir":
                //distinguimos entre los diferentes casos del comando describir
                switch (partes[1]) {
                    case "jugador":
                        //llamamos al metodo q describe un jugador
                        descJugador(comando);
                        break;
                    default:
                        //llamamos al metodo q describe una casilla
                        descCasilla(partes[1]);
                        break;
                }
                break;
            case "comprar":
                //comprobamos si el comando es comprar casilla y si tiene al menos 2 partes para q pueda hacer bien la ejecucion
                if (partes.length != 2) {
                    System.out.println("El comando 'comprar' debe ir seguido del nombre de la casilla a comprar.\n");
                    break;
                }
                //llamamos al metodo para comprar la casilla
                comprar(partes[1]);
                break;
            case "ver":
                //comprobamos si el comando es ver tablero y printeamos el tablero
                System.out.println(tablero);
                break;
            case "edificar":
                if (partes.length <= 4) {
                    if(partes[1].equals("pista") && partes[2].equals("de") && partes[3].equals("deporte")){
                        partes[1]="Pista de deporte";
                    }
                    if(this.existeTipoEdificio(partes[1])){
                        // Le aplicamos el método Capitalize para que funcione correctamente con mayúsculas y minúsculas
                        partes[1] = partes[1].substring(0, 1).toUpperCase() + partes[1].substring(1).toLowerCase();
                        int idEdificio = tablero.contarEdificiosTipo(partes[1]) + 1;
                        this.getJugadores().get(turno).getAvatar().getLugar().construirEdificio(partes[1], idEdificio);
                    } else {
                        System.out.println("No existe tal tipo de edificio\n");
                        break;
                    }
                } else {
                    System.out.println("El comando 'edificar' debe  ir seguido de 'casa', 'hotel', 'piscina' o 'pista de deporte'\n");
                    break;
                }
                break;
            case "hipotecar":
                Casilla hipo = tablero.buscarCasilla(partes[1]);
                if(hipo==null){
                    System.out.println("La casilla "+partes[1]+" no existe en el tablero.\n");
                    break;
                }
                if(hipo.getDuenho().getNombre().equals(jugadores.get(turno).getNombre())){
                    hipo.hipotecar();
                }
                else{
                    System.out.println("El jugador "+jugadores.get(turno).getNombre()+" no puede hipotecar " + hipo.getNombre() +".  No es una propiedad que le pertenece\n");
                }
                break;
            case "deshipotecar":
                Casilla deshipo = tablero.buscarCasilla(partes[1]);
                if(deshipo==null){
                    System.out.println("La casilla "+partes[1]+" no existe en el tablero.\n");
                    break;
                }
                if(deshipo.getDuenho().getNombre().equals(jugadores.get(turno).getNombre())){
                    deshipo.deshipotecar();
                }
                else{
                    System.out.println("El jugador "+ jugadores.get(turno).getNombre() +" no puede deshipotecar " + deshipo.getNombre() +".  No es una propiedad que le pertenece\n");
                }
                break;
            case "vender":
                if (partes.length < 4) {
                    System.out.println("El comando 'vender' debe ir seguido del tipo de propiedad que se quiere vender, el nombre de la casilla y el numero de propiedades que se quieren vender.");
                } else {
                    if(partes[1].equals("Pista") && partes[2].equals("de") && partes[3].equals("deporte")){
                        partes[1]="Pista de deporte";
                        partes[3]=partes[5];
                        partes[2]=partes[4];
                    }
                    Casilla aVender = tablero.buscarCasilla(partes[2]);
                    if(aVender==null){
                        System.out.println("La casilla "+partes[2]+" no existe en el tablero.\n");
                        break;
                    }
                    // Le aplicamos el método Capitalize para que funcione correctamente con mayúsculas y minúsculas
                    partes[1] = partes[1].substring(0, 1).toUpperCase() + partes[1].substring(1).toLowerCase();
                    if(!this.existeTipoEdificio(partes[1])){
                        System.out.println("No existe tal tipo de edificio\n");
                    }
                    else {
                        aVender.venderEdificio(partes[1], Integer.parseInt(partes[3]));
                    }
                }
                break;
            case "estadisticas":
                if (partes.length == 1) {
                    //llamamos al metodo para ver las estadisticas de la partida
                    estadisticasPartida();
                } else if (partes.length == 2) {
                    //llamamos al metodo para ver las estadisticas de un jugador
                    estadisticasJugador(partes[1]);
                } else {
                    System.out.println("El comando 'estadisticas' debe ir seguido de 'partida'.\n");
                }
                break;
            default:
                System.out.println("Ese comando no existe\n");
                break;
        }
    }

    /*Método que realiza las acciones asociadas al comando 'describir jugador'.
     * Parámetro: comando introducido
     */
    private void descJugador(String comando) {
        String partes[] = comando.split(" ");
        //partimos el comando en sus diferentes partes y comprobamos si tiene 1 o 3 partes
        //si tiene 1 parte decimos el jugador que tiene el turno
        if (partes.length == 1) {
            Jugador jugador = jugadores.get(turno);
            String mensaje = "{\n\tnombre: " + jugador.getNombre() + ",\n\tavatar: " + jugador.getAvatar();
            System.out.println(mensaje + "\n}\n");
        }
        //si tiene 3 partes buscamos el jugador con el nombre indicado y mostramos su informacion
        else if (partes.length == 3) {
            String nombreJugador = partes[2];
            //verificamos q exista dicho jugador dentro de nuestra lista de jugadores y printeamos su informacion
            for (Jugador jugador : jugadores) {
                if (jugador.getNombre().equals(nombreJugador)) {
                    String mensaje = "{\n\tnombre: " + jugador.getNombre() +
                            ",\n\tavatar: " + jugador.getAvatar() +
                            ",\n\tfortuna: " + (int) jugador.getFortuna();
                    //Recorremos la lista de propiedades del jugador para printearlas si las tiene
                    if (!jugador.getPropiedades().isEmpty()) {
                        mensaje += ",\n\tpropiedades: [";
                        for (Casilla casilla : jugador.getPropiedades()) {
                            mensaje += casilla.getNombre();
                            if (casilla != jugador.getPropiedades().getLast()) {
                                mensaje += ", ";
                            }
                        }
                        mensaje += "]";
                    }
                    //Recorremos la lista de edificios del jugador para printearlos si los tiene
                    if (!jugador.getEdificios().isEmpty()) {
                        mensaje += "\n\tedificios: [";
                        int j = 0;
                        //recorremos la lista de edificios del jugador para printearlas
                        for (Edificio edificio : jugador.getEdificios()) {
                            mensaje += edificio.getTipo() + "-" + edificio.getIdentificador();
                            if (j < jugador.getEdificios().size() - 1) {
                                mensaje += (",");
                                j++;
                            }
                        }
                        mensaje += "]\n\t";
                    }
                    System.out.println(mensaje + "\n}\n");
                    return;
                }
            }
            System.out.println("El jugador " + nombreJugador + " no existe en la partida.\n");
            return;
        }
    }

    /*Método que realiza las acciones asociadas al comando 'describir avatar'.
     * Parámetro: id del avatar a describir.
     */
    private void descAvatar(String ID) {
        for (Jugador jugador : jugadores) {
            Avatar avatar = jugador.getAvatar();
            if (avatar.getId().equals(ID)) {
                descJugador("descibir jugador" + " " + jugador.getNombre());
                return;
            }
        }
    }


    /* Método que realiza las acciones asociadas al comando 'describir nombre_casilla'.
     * Parámetros: nombre de la casilla a describir.
     */
    private void descCasilla(String nombre) {
        //buscamos la casilla en el tablero
        Casilla casilla = tablero.buscarCasilla(nombre);
        //verificamos q sea diferente de null para printear su informacion
        if (casilla != null) {
            System.out.println(casilla.infoCasilla());
        }
        //en el caso contrario informamos de que no existe dicha casilla
        else {
            System.out.println("La casilla " + nombre + " no existe en el tablero.\n");
        }
    }

    //Método que ejecuta todas las acciones relacionadas con el comando 'lanzar dados'.
    private void lanzarDados() {
        //verificamos q haya jugadores en la partida
        if (jugadores.isEmpty()) {
            System.out.println("No hay jugadores en la partida. No se pueden lanzar los dados.\n");
            return;
        }
        //realizamos la tirada de ambos dados y llamamos al metodo para poder avanzar las casillas correspondientes
        dado1.hacerTirada();
        dado2.hacerTirada();
        realizarTirada(dado1, dado2, jugadores.get(turno));
    }

    //Método que ejecuta todas las acciones relacionadas con el comando 'lanzar dados' con valores forzados.
    private void lanzarDadosForzados(int a, int b) {
        //verificamos q haya jugadores en la partida
        if (jugadores.isEmpty()) {
            System.out.println("No hay jugadores en la partida. No se pueden lanzar los dados.\n");
            return;
        }
        //realizamos la tirada de ambos dados con los valores forzados y llamamos al metodo para poder avanzar las casillas correspondientes
        dado1.hacerTirada(a);
        dado2.hacerTirada(b);
        realizarTirada(dado1, dado2, jugadores.get(turno));
    }

    private void realizarTirada(Dado d1, Dado d2, Jugador jugador) {
        tirado = false;
        //comprobamos q el jugador no haya tirado ya y no este en la carcel
        if (!tirado && !jugador.getenCarcel()) {
            //movemos el avatar del jugador la suma de ambos dados
            jugador.getAvatar().moverAvatar(tablero.getPosiciones(), dado1.getValor() + dado2.getValor());
            //verificamos si se han sacado dobles o no y se actualiza el contador de lanzamientos
            tirado = !(dado1.sonDobles(dado2));
            if (tirado == false) {
                lanzamientos += 1;
            }
            //si se han sacado dobles 3 veces seguidas el jugador va a la carcel
            if (lanzamientos == 3 && dado1.sonDobles(dado2)) {
                System.out.println("El jugador " + jugadores.get(turno).getNombre() + " ha tirado dobles tres veces seguidas y va a la carcel.\n");
                jugadores.get(turno).encarcelar(tablero.getPosiciones());
                tirado = true;
            }
            // comprobamos si el jugador no ha tirado ya y si esta en la carcel
        } else if (!tirado && jugador.getenCarcel()) {
            //actualizamos las tiradas en la carcel del jugador
            jugador.setTiradasCarcel(jugadores.get(turno).getTiradasCarcel() + 1);
            //verificamos si son dobles para comprobar si sale de la carcel y como ha sacado dobles reseteamos sus tiradas en la carcel y le dejamos q pueda mover su avatar y pueda volver a tirar
            if (dado1.sonDobles(dado2)) {
                System.out.println("El jugador " + jugadores.get(turno).getNombre() + " ha sacado dobles y sale de la carcel.\n");
                jugador.setEnCarcel(false);
                jugador.setTiradasCarcel(0);
                jugador.getAvatar().moverAvatar(tablero.getPosiciones(), dado1.getValor() + dado2.getValor());
                tirado = false;
            }
            //si no ha sacado dobles y ya ha tirado 3 veces en la carcel paga el impuesto y sale de la carcel moviendo su avatar
            if (!dado1.sonDobles(dado2) && jugadores.get(turno).getTiradasCarcel() > 2) {
                salirCarcel();
                jugador.getAvatar().moverAvatar(tablero.getPosiciones(), dado1.getValor() + dado2.getValor());
            }
        } else {
            System.out.println("El jugador " + jugador.getNombre() + " ya ha tirado los dados este turno.\n");
        }
    }

    /*Método que ejecuta todas las acciones realizadas con el comando 'comprar nombre_casilla'.
     * Parámetro: cadena de caracteres con el nombre de la casilla.
     */
    private void comprar(String nombre) {
        //buscamos la casilla en el tablero y obtenemos el jugador que tiene el turno
        Casilla casilla = tablero.buscarCasilla(nombre);
        Jugador jugador = jugadores.get(turno);
        //verificamos q la casilla no sea null para proceder a la compra
        if (casilla != null) {
            //verificamos q el dueño de la casilla sea la banca y q el jugador este en la casilla para poder comprarla
            if (casilla.getDuenho().equals(banca)) {
                if (jugadores.get(turno).getAvatar().getLugar() != casilla) {
                    System.out.println("El jugador " + jugador.getNombre() + " no está en la casilla " + nombre + " y no puede comprarla.\n");
                } else {
                    //realizamos la compra de la casilla
                    casilla.comprarCasilla(jugador, banca);
                }
            }
            //si la casilla no pertenece a la banca informamos de su dueño
            else {
                System.out.println("La casilla " + nombre + " le pertenece a " + casilla.getDuenho().getNombre() + "\n");
            }
        }
        //en caso de que no este en el tablero informamos de que no existe dicha casilla
        else {
            System.out.println("La casilla " + nombre + " no existe en el tablero.\n");
        }
    }

    //Método que ejecuta todas las acciones relacionadas con el comando 'salir carcel'.
    private void salirCarcel() {
        //sacamos el jugador q tiene el turno y realizamos las acciones para salir de la carcel pagando el impuesto
        Jugador jugador = jugadores.get(turno);
        jugador.setEnCarcel(false);
        jugador.sumarGastos(IMPUESTO_CARCEL);
        jugador.sumarFortuna(-IMPUESTO_CARCEL);
        System.out.println(jugador.getNombre() + " paga " + IMPUESTO_CARCEL + " y sale de la carcel. Puede lanzar los dados\n");
    }

    // Método que realiza las acciones asociadas al comando 'listar enventa'.
    private void listarVenta() {
        //recorremos todas las casillas del tablero y printeamos las que esten en venta (aquellas cuyo dueño sea la banca)
        for (ArrayList<Casilla> lado : tablero.getPosiciones()) {
            for (Casilla casilla : lado) {
                if (casilla.casEnVenta() != null) {
                    System.out.println(casilla.casEnVenta());
                }
            }
        }
    }

    // Método que realiza las acciones asociadas al comando 'listar jugadores'.
    private void listarJugadores() {
        int i = 0;
        // recorremos la lista de jugadores con un for each para printear su informacion
        for (Jugador jugador : jugadores) {
            System.out.println("{\n");
            System.out.println("\tnombre: " + jugador.getNombre()
                    + ",\n\tavatar: " + jugador.getAvatar().getTipo()
                    + ",\n\tfortuna: " + (int) jugador.getFortuna());
            //verificamos si el jugador tiene propiedades para printearlas
            if (!jugador.getPropiedades().isEmpty()) {
                System.out.print("\tpropiedades: [");
                int j = 0;
                //recorremos la lista de propiedades del jugador para printearlas
                for (Casilla casilla : jugador.getPropiedades()) {
                    System.out.print(casilla.getNombre());
                    if (j < jugador.getPropiedades().size() - 1) {
                        System.out.print(",");
                        j++;
                    }
                }
                System.out.print("]\n\t");
            }
            // verificamos si el jugador tiene edificios para printearlos
            if (!jugador.getEdificios().isEmpty()) {
                System.out.print("edificios: [");
                int j = 0;
                //recorremos la lista de edificios del jugador para printearlas
                for (Edificio edificio : jugador.getEdificios()) {
                    System.out.print(edificio.getTipo() + "-" + edificio.getIdentificador());
                    if (j < jugador.getEdificios().size() - 1) {
                        System.out.print(",");
                        j++;
                    }
                }
                System.out.print("]\n");
            }
            if (i < jugadores.size() - 1) {
                System.out.println("},\n");
                i++;
            }
        }
        System.out.println("}\n");
    }

    // Método que realiza las acciones asociadas al comando 'listar edificios', al no pasarle ningún arg.
    private void listarEdificios() {
        //recorremos todas las casillas del tablero y printeamos los edificios que haya en cada una
        for (ArrayList<Casilla> lado : tablero.getPosiciones()) {
            for (Casilla casilla : lado) {
                //verificamos si hay edificios en la casilla para printearlos
                if (!casilla.edificiosCasilla().isEmpty()) {
                    // en caso de que haya edificios los printeamos
                    for (Edificio edificio : casilla.edificiosCasilla()) {
                        if (casilla.edificiosCasilla().getLast().equals(edificio)) {
                            System.out.println(edificio);
                        } else {
                            System.out.println(edificio + ",\n");
                        }
                    }
                }
            }
        }
    }

    //Método que realiza las acciones asociadas al comando 'listar edificios', al pasarle el grupo de la casilla como arg.
    private void listarEdificiosGrupo(String grupo) {

        boolean flagHoteles = false, flagPiscinas = false, flagPistas = false;
        // obtenemos las casillas del grupo indicado
        ArrayList<Casilla> CasillasGrupo = tablero.getGrupos().get(grupo).getMiembros();
        // recorremos las casillas del grupo y printeamos los edificios que haya en cada una
        for (Casilla casilla : CasillasGrupo) {
            //verificamos si hay edificios en la casilla para printearlos
            if (!casilla.edificiosCasilla().isEmpty()) {
                System.out.print("Propiedad: " + casilla.getNombre() + "\n");
                System.out.print("Hoteles: ");
                //verificamos si hay hoteles en la casilla para printearlos
                if (casilla.getHoteles().isEmpty()) {
                    // en caso de que no haya hoteles ponemos un guion y activamos el flag
                    flagHoteles = true;
                    System.out.print("-");
                } else {
                    // en caso de que haya hoteles los printeamos recorriendo la lista de hoteles
                    for (Edificio edificio : casilla.getHoteles()) {
                        System.out.print("[Hotel-" + edificio.getIdentificador() + "],");
                    }
                }
                System.out.print("\nCasas: ");
                //verificamos si hay casas en la casilla para printearlas
                if (casilla.getCasas().isEmpty()) {
                    System.out.print("-");
                } else {
                    // en caso de que haya casas las printeamos recorriendo la lista de casas
                    for (Edificio edificio : casilla.getCasas()) {
                        System.out.print("[Casa-" + edificio.getIdentificador() + "],");
                    }
                }
                System.out.print("\nPiscinas: ");
                //verificamos si hay piscinas en la casilla para printearlas
                if (casilla.getPiscinas().isEmpty()) {
                    // en caso de que no haya piscinas ponemos un guion y activamos el flag
                    flagPiscinas = true;
                    System.out.print("-");
                } else {
                    // en caso de que haya piscinas las printeamos recorriendo la lista de piscinas
                    for (Edificio edificio : casilla.getPiscinas()) {
                        System.out.print("[Piscina-" + edificio.getIdentificador() + "],");
                    }
                }
                // printeamos las pistas de deporte
                System.out.print("\nPistas de Deporte: ");
                //verificamos si hay pistas de deporte en la casilla para printearlas
                if (casilla.getPistasDeporte().isEmpty()) {
                    // en caso de que no haya pistas de deporte ponemos un guion y activamos el flag
                    flagPistas = true;
                    System.out.print("-");
                } else {
                    // en caso de que haya pistas de deporte las printeamos recorriendo la lista de pistas de deporte
                    for (Edificio edificio : casilla.getPistasDeporte()) {
                        System.out.print("[Pista-" + edificio.getIdentificador() + "],");
                    }
                }
            }
        }
        System.out.println("\n");
        // en funcion de los flags activados printeamos los mensajes correspondientes
        if (flagHoteles) {
            System.out.println("Aún se pueden construir hoteles, piscinas y pistas de deporte en este grupo.\n");
        }
        if (flagPiscinas && !flagHoteles) {
            System.out.println("Aún se pueden construir piscinas y pistas de deporte en este grupo. Ya no se pueden construir casas ni hoteles\n");
        }
        if (flagPistas && !flagHoteles && !flagPiscinas) {
            System.out.println("Aún se pueden construir pistas de deporte en este grupo. Ya no se pueden construir casas,hoteles ni piscinas\n");
        }
        if (flagHoteles && flagPiscinas && flagPistas) {
            System.out.println("Ya no se pueden construir más edificios en este grupo.\n");
        }
        if (!flagHoteles && !flagPiscinas && !flagPistas) {
            System.out.println("Es posible construir cualquier edificio en este grupo. Consigue 4 casas primero.\n");
        }
    }

    // Método que realiza las acciones asociadas al comando 'listar avatares'.
    private void listarAvatares() {
    }

    // Método que realiza las acciones asociadas al comando 'acabar turno'.
    private void acabarTurno() {
        // actualizamos el turno al siguiente jugador
        int i = jugadores.size();
        boolean checkVueltas=true;
        turno = (turno + 1) % i;
        tirado = false;
        lanzamientos = 0;
        // comprobamos si todos los jugadores han dado 4 vueltas para incrementar el valor de los solares
        for(Jugador j: jugadores){
            if(j.getVueltas()<4 || incrementoSolares==1){
                checkVueltas = false;
                break;
            }
        }
        if(checkVueltas && incrementoSolares==0){
            tablero.incrementarValorSolares();
            incrementoSolares = 1;
        }
    }

    private boolean existeTipoEdificio(String tipo){
        // comprobamos si el tipo de edificio es valido
        tipo = tipo.substring(0, 1).toUpperCase()+tipo.substring(1).toLowerCase();
        if(tipo.equals("Pista de deporte") || tipo.equals("Piscina") || tipo.equals("Hotel") || tipo.equals("Casa")){
            return true;
        }
        return false;
    }

    private void suerte_comunidad() {
        // comprobamos si la casilla en la que ha caido el jugador es de tipo suerte o comunidad y aplicamos el efecto correspondiente
        switch (jugadores.get(turno).getAvatar().getLugar().getTipo()) {
            // en el caso de que sea suerte aplicamos el efecto correspondiente segun el valor de la variable suerte
            case "Suerte":
                switch (suerte) {
                    case 1:
                        // printeamos el mensaje correspondiente y movemos el avatar del jugador a la casilla solar19
                        System.out.println("Decides hacer un viaje de placer. Avanza hasta Solar19. Si pasas por la casilla de salida, combra " + SUMA_VUELTA + "€");
                        if (33 - jugadores.get(turno).getAvatar().getLugar().getPosicion() < 0) {
                            // ya se ha avanzado mas alla de la casilla 19 por lo que hay q dar una vuelta entera
                            jugadores.get(turno).getAvatar().moverAvatar(tablero.getPosiciones(), 32 - jugadores.get(turno).getAvatar().getLugar().getPosicion() + 40);
                        } else {
                            jugadores.get(turno).getAvatar().moverAvatar(tablero.getPosiciones(), 32 - jugadores.get(turno).getAvatar().getLugar().getPosicion());
                        }
                        break;
                    case 2:
                        // printeamos el mensaje correspondiente y encarcelamos al jugador
                        System.out.println("Los acreedores te persiguen por impago. Ve a la Cárcel. Ve directamente sin pasar por la casilla de Salida y sin cobrar los 2.000.000€");
                        jugadores.get(turno).encarcelar(tablero.getPosiciones());
                        break;
                    case 3:
                        // printeamos el mensaje correspondiente y sumamos 1.000.000€ a la fortuna del jugador asi como a sus premios por inversiones y bote
                        System.out.println("¡Has ganado el bote de la loteria! Recibe 1.000.000€");
                        jugadores.get(turno).sumarFortuna(1000000);
                        jugadores.get(turno).sumarpremiosinversionesbote(1000000);
                        break;
                    case 4:
                        // printeamos el mensaje correspondiente y restamos 250.000€ a la fortuna del jugador por cada jugador contrario ademas de darselos al resto de jugadores y sumar los gastos e impuestos correspondientes
                        System.out.println("Has sido elegido presidente de la junta directiva. Paga a cada jugador 250.000€");
                        for (Jugador jugador : jugadores) {
                            if (!jugador.equals(jugadores.get(turno))) {
                                if (jugadores.get(turno).puedePagar(250000)) {
                                    jugador.sumarFortuna(250000);
                                    jugador.sumarpremiosinversionesbote(250000);
                                    jugadores.get(turno).sumarFortuna(-250000);
                                    jugadores.get(turno).sumarGastos(250000);
                                    jugadores.get(turno).sumarimpuestos(250000);                                }
                            }
                        }
                        break;
                    case 5:
                        // printeamos el mensaje correspondiente y movemos el avatar del jugador 3 casillas hacia atras
                        System.out.println("¡Hora punta de tráfico! Retrocede tres casillas.");
                        jugadores.get(turno).getAvatar().moverAvatar(tablero.getPosiciones(), -3);
                        break;
                    case 6:
                        System.out.println("Te multan por usar el móvil mientras conduces. Paga 150.000€");
                        if (jugadores.get(turno).puedePagar(150000)) {
                            jugadores.get(turno).sumarFortuna(-150000);
                            jugadores.get(turno).sumarGastos(150000);
                            jugadores.get(turno).sumarimpuestos(150000);
                        }
                        break;
                    case 7:
                        // printeamos el mensaje correspondiente y movemos el avatar del jugador hasta la casilla de transporte mas cercana
                        System.out.println("Avanza hasta la casilla de transporte mas cercana. Si no tiene dueño, puedes comprarla. Si tiene dueño, paga al dueño el doble de la operación indicada");
                        // sacamos la posicion actual del jugador
                        int posActual = jugadores.get(turno).getAvatar().getLugar().getPosicion();
                        int posfinal = 0;
                        // en funcion de su posicion actual movemos su avatar a la casilla de transporte mas cercana ( utilizamos el switch para diferenciar entre cada una de las posiciones de las casillas suerte detro de nuestro tablero)
                        switch (posActual) {
                            case 7:
                                jugadores.get(turno).getAvatar().moverAvatar(tablero.getPosiciones(), -2);
                                if (jugadores.get(turno).getAvatar().getLugar().getDuenho().equals(banca) || jugadores.get(turno).getAvatar().getLugar().getDuenho().equals(jugadores.get(turno))) {
                                    break;
                                } else {
                                    jugadores.get(turno).getAvatar().getLugar().pagarDeudas(jugadores.get(turno).getAvatar().getLugar().getDuenho(), jugadores.get(turno), 2);
                                }
                                break;
                            case 22:
                                jugadores.get(turno).getAvatar().moverAvatar(tablero.getPosiciones(), 3);
                                if (jugadores.get(turno).getAvatar().getLugar().getDuenho().equals(banca) || jugadores.get(turno).getAvatar().getLugar().getDuenho().equals(jugadores.get(turno))) {
                                    break;
                                } else {
                                    jugadores.get(turno).getAvatar().getLugar().pagarDeudas(jugadores.get(turno).getAvatar().getLugar().getDuenho(), jugadores.get(turno), 3);
                                }
                                break;
                            case 36:
                                jugadores.get(turno).getAvatar().moverAvatar(tablero.getPosiciones(), -1);
                                if (jugadores.get(turno).getAvatar().getLugar().getDuenho().equals(banca) || jugadores.get(turno).getAvatar().getLugar().getDuenho().equals(jugadores.get(turno))) {
                                    break;
                                } else {
                                    jugadores.get(turno).getAvatar().getLugar().pagarDeudas(jugadores.get(turno).getAvatar().getLugar().getDuenho(), jugadores.get(turno), 1);
                                }
                                break;
                        }
                        // dentro de cada caso comprobamos si la casilla de transporte tiene dueño o no para proceder a pagar o no la deuda multiplicada x2
                        break;
                    default:
                        break;
                }
                // actualizamos el valor del discriminante establecido como atributo y revisamos que no sobrepasa el maximo, en caso contrario reseteamos al valor 1
                suerte++;
                if (suerte > 7) {
                    suerte = 1;
                }
                break;
            case "Comunidad":
                // en caso de caer en la casilla de comunidad aplicamos el efecto correspondiente segun el valor de la variable comunidad
                switch (comunidad) {
                    case 1:
                        // printeamos el mensaje correspondiente y restamos 500.000€ a la fortuna del jugador por un gasto de ocio asi como le sumamos los impuestos correspondientes y los gastos
                        System.out.println("Paga 500.000€ por un fin de semana en un balneario de 5 estrellas.");
                        if (jugadores.get(turno).puedePagar(500000)) {
                            jugadores.get(turno).sumarFortuna(-500000);
                            jugadores.get(turno).sumarGastos(500000);
                            jugadores.get(turno).sumarimpuestos(500000);
                        }
                        break;
                    case 2:
                        // printeamos el mensaje correspondiente y encarcelamos al jugador
                        System.out.println("Te investigan por fraude de identidad. Ve a la Cárcel. Ve directamente sin pasar por la casilla de Sailda y sin cobrar los 2.000.000€");
                        jugadores.get(turno).encarcelar(tablero.getPosiciones());
                        break;
                    case 3:
                        // printeamos el mensaje correspondiente y movemos el avatar del jugador a la casilla de salida
                        System.out.println("Colócate en la casilla de salida. Cobra 2.000.000€");
                        int posicion = jugadores.get(turno).getAvatar().getLugar().getPosicion();
                        jugadores.get(turno).getAvatar().moverAvatar(tablero.getPosiciones(), 40 - posicion);
                        break;
                    case 4:
                        // printeamos el mensaje correspondiente y sumamos 500.000€ a la fortuna del jugador asi como a sus premios por inversiones y bote
                        System.out.println("Devolucion de Hacienda. Cobra 500.000€");
                        jugadores.get(turno).sumarFortuna(500000);
                        jugadores.get(turno).sumarpremiosinversionesbote(500000);
                        break;
                    case 5:
                        // printeamos el mensaje correspondiente y movemos el avatar del jugador a la casilla solar1
                        System.out.println("Retrocede hasta Solar1 para comprar antigüedades exoticas.");
                        posicion = jugadores.get(turno).getAvatar().getLugar().getPosicion();
                        jugadores.get(turno).getAvatar().moverAvatar(tablero.getPosiciones(), -posicion + 1);
                        break;
                    case 6:
                        // printeamos el mensaje correspondiente y movemos el avatar del jugador a la casilla solar20
                        System.out.println("Ve al solar 20 para disfrutar del San Fermín. Si pasas por la casilla de salida, cobra 2.000.000€");
                        posicion = jugadores.get(turno).getAvatar().getLugar().getPosicion();
                        // volvemos a hacer la diferenciacion para comprobar si se tiene que pasar por salida o no
                        if (34 - posicion < 0) {
                            jugadores.get(turno).getAvatar().moverAvatar(tablero.getPosiciones(), 34 - posicion + 40);
                        } else {
                            jugadores.get(turno).getAvatar().moverAvatar(tablero.getPosiciones(), 34 - posicion);
                        }
                        break;
                    default:
                        break;
                }
                // actualizamos el valor del discriminante establecido como atributo y revisamos que no sobrepasa el maximo, en caso contrario reseteamos al valor 1
                comunidad++;
                if (comunidad > 6) {
                    comunidad = 1;
                }
                break;
            default:
                break;
        }
    }

    private void estadisticasPartida() {
        Casilla masvisitada = null;
        Casilla masrentable = null;
        float rentabilidadmax = 0;
        int maxvisitas = 0;
        // recorremos todas las casillas del tablero para obtener la casilla mas visitada y la mas rentable
        for(ArrayList <Casilla> lado : tablero.getPosiciones()){
                for (Casilla c : lado) {
                    if (c.getVisitada() > maxvisitas) {
                        maxvisitas = c.getVisitada();
                        masvisitada = c;
                    }
                    // diferenciamos entre las casillas que pertenecen a la banca y las que no para obtener la mas rentable entre las que no pertenecen a la banca
                    if(!c.getDuenho().equals(banca)){
                        // calculamos la rentabilidad de la casilla y comprobamos si es mayor que la maxima actual actualizandola en caso afirmativo
                        if((c.getGenerado()/c.gastosTotales()) > rentabilidadmax){
                            rentabilidadmax = (c.getGenerado()/c.gastosTotales());
                            masrentable = c;
                        }
                    }
                }
            }
        Grupo gruporentable=null;
        float rentabilidadmaxgrupo=0;
        ArrayList<String> nombresgrupos= new ArrayList<>();
        nombresgrupos.add("Marron");
        nombresgrupos.add("Cyan");
        nombresgrupos.add("Rosa");
        nombresgrupos.add("Salmon");
        nombresgrupos.add("Rojo");
        nombresgrupos.add("Amarillo");
        nombresgrupos.add("Verde");
        nombresgrupos.add("Azul");
        // recorremos todos los grupos del tablero para obtener el grupo mas rentable
        for (String nombregrupo : nombresgrupos) {
            // sacamos el grupo del tablero y comprobamos su rentabilidad
            Grupo g = tablero.getGrupos().get(nombregrupo);
            // si la rentabilidad del grupo es mayor que la maxima actual actualizamos la maxima y el grupo mas rentable
            if(g.rentabilidadgrupo()>rentabilidadmaxgrupo){
                rentabilidadmaxgrupo=g.rentabilidadgrupo();
                gruporentable=g;
            }
        }
        Jugador mayorvueltas = null;
        int maxvueltas = 0;
        // recorremos todos los jugadores para obtener el que mas vueltas ha dado
        for (Jugador j : jugadores) {
            // si el numero de vueltas del jugador es mayor que el maximo actual actualizamos el maximo y el jugador con mas vueltas
            if (j.getVueltas() > maxvueltas) {
                maxvueltas = j.getVueltas();
                mayorvueltas = j;
            }
        }
        float maxfortuna = 0;
        Jugador mayorfortuna = null;
        // recorremos todos los jugadores para obtener el que tiene mayor fortuna total (fortuna + valor de propiedades + valor de edificios)
        for (Jugador j : jugadores) {
            // calculamos la fortuna total del jugador
            // comenzamos con su fortuna actual
            float fortunaactual = j.getFortuna();
            // le sumamos el valor de sus propiedades
            ArrayList<Casilla> propiedades = j.getPropiedades();
            for (Casilla c : propiedades) {
                fortunaactual += c.getValor();
            }
            // le sumamos el valor de sus edificios
            ArrayList<Edificio> edificios = j.getEdificios();
            for (Edificio e : edificios) {
                fortunaactual += e.getPrecio();
            }
            // si la fortuna total del jugador es mayor que la maxima actual actualizamos la maxima y el jugador con mayor fortuna
            if (fortunaactual > maxfortuna) {
                maxfortuna = fortunaactual;
                mayorfortuna = j;
            }
        }
        // printeamos las estadisticas obtenidas en caso de que existan.
        System.out.println("{\n");
        if(masrentable!=null){
            System.out.println("casillaMasRentable: " + masrentable.getNombre() + ",\n ");
        }
        if(gruporentable!=null){
            System.out.println("grupoMasRentable: " + gruporentable + ",\n ");
        }
        if(masvisitada!=null){
            System.out.println("casillaMasFrecuentada: " + masvisitada.getNombre() + ",\n ");
        }
        if(mayorvueltas!=null){
            System.out.println("jugadorMasVueltas " + mayorvueltas.getNombre() + " ,\n ");
        }
        if(mayorfortuna!=null){
            System.out.println("jugadorEnCabeza: " + mayorfortuna.getNombre() + "\n ");
        }
        System.out.println("}\n");
    }

    private void estadisticasJugador(String nombrejugador) {
        Jugador jugador = null;
        // buscamos el jugador con el nombre indicado
        for (Jugador j : jugadores) {
            if (j.getNombre().equals(nombrejugador)) {
                jugador = j;
                break;
            }
        }
        // en caso de que el jugador exista printeamos sus estadisticas
        if(jugador != null) {
            float dineroInvertido = 0;
            // sacamos el valor de gastos totales de todas las propiedades del jugador y los sumamos dentro de la variable dineroInvertido
            for(Casilla casilla:jugador.getPropiedades()){
                dineroInvertido += casilla.gastosTotales();
            }
            // sacamos el valor de gastos totales por impuestos
            float pagoTasasEImpuestos = jugador.getDineroPorImpuestos();
            // sacamos el valor de dinero pagado por alquileres
            float pagodealquileres = jugador.getDineroPorAlquileres();
            // sacamos el valor de dinero cobrado por alquileres
            float cobrodealquileres = jugador.getCobrosPorAlquileres();
            // sacamos el valor de dinero cobrado por pasar por la casilla de salida
            float pasarporcasilladesalida = jugador.getVueltas() * SUMA_VUELTA;
            // sacamos el valor de premios por inversiones o bote
            float premiosinversionesobote = jugador.getPremiosInversionesOBote();
            // sacamos el numero de veces que el jugador ha ido a la carcel
            int vecesenlacarcel = jugador.getVecesCarcel();
            System.out.println("{\n");
            System.out.println("dineroInvertido: " + (int) dineroInvertido + ",\n");
            System.out.println("pagoTasasEImpuestos: " + (int) pagoTasasEImpuestos + ",\n");
            System.out.println("pagodealquileres: " + (int) pagodealquileres + ",\n");
            System.out.println("cobrodealquileres: " + (int) cobrodealquileres + ",\n");
            System.out.println("pasarporcasilladesalida: " + (int) pasarporcasilladesalida + ",\n");
            System.out.println("premiosinversionesobote: " + (int) premiosinversionesobote + ",\n");
            System.out.println("vecesenlacarcel: " + vecesenlacarcel + "\n");
            System.out.println("}\n");
        }
        // en caso de que el jugador no exista informamos de ello
        else{
            System.out.println("El jugador " + nombrejugador + " no existe en la partida.\n");
        }
    }
        // Método de Bancarrota utilizado para mostrar a un jugador cuando entra en bancarrota y elija entre
        // hipotecar sus propiedades o perder la partida
        public void bancarrota(Jugador jugador) {
            System.out.println("El jugador " + jugador.getNombre() + " ha entrado en bancarrota y debe elegir entre hipotecar sus propiedades o perder la partida.\n");
            System.out.println("¿Quieres hipotecarte o perder la partida?");
            // Hazme aquí un scanf pero de Java

        }
}


