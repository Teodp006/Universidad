package monopoly;

import partida.*;
import java.util.ArrayList;


class Grupo {

    //Atributos
    private ArrayList<Casilla> miembros; //Casillas miembros del grupo.
    private String colorGrupo; //Color del grupo
    private int numCasillas; //Número de casillas del grupo.
    private float precioCasa; //Precio de las casas en ese grupo.
    private float precioHotel; //Precio de los hoteles en ese grupo.
    private float precioPiscina; //Precio de las piscinas en ese grupo.
    private float precioPistaDeporte; //Precio de las pistas de deporte en ese

    //Constructor vacío.
    public Grupo() {
    }

    //Getters y Setters
    public ArrayList<Casilla> getMiembros() {
        return miembros;
    }
    public void setMiembros(ArrayList<Casilla> miembros) {
        this.miembros = miembros;
    }
    public String getColorGrupo() {
        return colorGrupo;
    }
    public void setColorGrupo(String colorGrupo) { this.colorGrupo = colorGrupo;}
    public int getNumCasillas() {
        return numCasillas;
    }
    public void setNumCasillas(int numCasillas) {
        this.numCasillas = numCasillas;
    }
    public float getPrecioCasa() { return  precioCasa; }
    public void setPrecioCasa(float precioCasa) { this.precioCasa = precioCasa; }
    public float getPrecioHotel() { return precioHotel; }
    public void setPrecioHotel(float precioHotel) { this.precioHotel = precioHotel; }
    public float getPrecioPiscina() { return precioPiscina; }
    public void setPrecioPiscina(float precioPiscina) { this.precioPiscina = precioPiscina; }
    public float getPrecioPistaDeporte() { return precioPistaDeporte; }
    public void setPrecioPistaDeporte(float precioPistaDeporte) { this.precioPistaDeporte = precioPistaDeporte; }

    /*Constructor para cuando el grupo está formado por DOS CASILLAS:
    * Requiere como parámetros las dos casillas miembro y el color del grupo.
     */
    public Grupo(Casilla cas1, Casilla cas2, String colorGrupo) {
        this.miembros=new ArrayList<>();
        miembros.add(cas1);
        miembros.add(cas2);
        this.colorGrupo=colorGrupo;
        this.numCasillas=miembros.size();
        this.precioCasa=precioConstruccion("Casa");
        this.precioHotel=precioConstruccion("Hotel");
        this.precioPiscina=precioConstruccion("Piscina");
        this.precioPistaDeporte=precioConstruccion("Pista de deporte");
    }

    /*Constructor para cuando el grupo está formado por TRES CASILLAS:
    * Requiere como parámetros las tres casillas miembro y el color del grupo.
     */
    public Grupo(Casilla cas1, Casilla cas2, Casilla cas3, String colorGrupo) {
        this.miembros = new ArrayList<>();
        this.miembros.add(cas1);
        this.miembros.add(cas2);
        this.miembros.add(cas3);
        this.colorGrupo = colorGrupo;
        this.numCasillas = miembros.size();
        this.precioCasa=precioConstruccion("Casa");
        this.precioHotel=precioConstruccion("Hotel");
        this.precioPiscina=precioConstruccion("Piscina");
        this.precioPistaDeporte=precioConstruccion("Pista de deporte");
        for(Casilla casilla: miembros){
            casilla.setGrupo(this);
        }
    }

    /* Método que añade una casilla al array de casillas miembro de un grupo.
    * Parámetro: casilla que se quiere añadir.
     */
    public void anhadirCasilla(Casilla miembro) {
        this.miembros.add(miembro);
        this.numCasillas++;
    }

    /*Método que comprueba si el jugador pasado tiene en su haber todas las casillas del grupo:
    * Parámetro: jugador que se quiere evaluar.
    * Valor devuelto: true si es dueño de todas las casillas del grupo, false en otro caso.
     */
    public boolean esDuenhoGrupo(Jugador jugador) {
        for (Casilla casilla : miembros) {
            if (casilla.getDuenho() != jugador) {
                return false;
            }
        }
    return true;}

    //Método toString para imprimir el grupo por su color con la primera letra en mayúscula.
    @Override
    public String toString() {
        return colorGrupo.substring(0, 1).toUpperCase() + colorGrupo.substring(1).toLowerCase(); // Imprime el color del grupo como Marron y no MARRON
    }

    //Metodo privado que devuelve el precio de construcción según el color del grupo y el tipo de construcción
    public float precioConstruccion(String tipoConstruccion) {
        float precio=0;
        switch (this.colorGrupo) {
            case "MARRON":
                switch(tipoConstruccion){
                    case "Casa":
                        return 500000;
                    case "Hotel":
                        return 500000;
                    case "Piscina":
                        return 100000;
                    case "Pista de deporte":
                        return 200000;
                }
            case "CYAN":
                switch(tipoConstruccion){
                    case "Casa":
                        return 500000;
                    case "Hotel":
                        return 500000;
                    case "Piscina":
                        return 100000;
                    case "Pista de deporte":
                        return 200000;
                }
            case "ROSA":
                switch(tipoConstruccion){
                    case "Casa":
                        return 1000000;
                    case "Hotel":
                        return 1000000;
                    case "Piscina":
                        return 2000000;
                    case "Pista de deporte":
                        return 400000;
                }
            case "SALMON":
                switch(tipoConstruccion){
                    case "Casa":
                        return 1000000;
                    case "Hotel":
                        return 1000000;
                    case "Piscina":
                        return 2000000;
                    case "Pista de deporte":
                        return 400000;
                }
            case "ROJO":
                switch(tipoConstruccion){
                    case "Casa":
                        return 1500000;
                    case "Hotel":
                        return 1500000;
                    case "Piscina":
                        return 300000;
                    case "Pista de deporte":
                        return 600000;
                }
            case "AMARILLO":
                switch(tipoConstruccion){
                    case "Casa":
                        return 1500000;
                    case "Hotel":
                        return 1500000;
                    case "Piscina":
                        return 300000;
                    case "Pista de deporte":
                        return 600000;
                }
            case "VERDE":
                switch(tipoConstruccion){
                    case "Casa":
                        return 2000000;
                    case "Hotel":
                        return 2000000;
                    case "Piscina":
                        return 400000;
                    case "Pista de deporte":
                        return 800000;
                }
            case "AZUL":
                switch(tipoConstruccion){
                    case "Casa":
                        return 2000000;
                    case "Hotel":
                        return 2000000;
                    case "Piscina":
                        return 400000;
                    case "Pista de deporte":
                        return 800000;
                }

        }
        return precio;
    }

    //Metodo que comprueba si todas las casillas del grupo están completas
    public boolean esGrupoCompleto() {
        if(this.getMiembros().isEmpty()) {
            return false;
        }
        for (Casilla casilla : this.getMiembros()) {
            if (!casilla.esCasillaCompleta()) {
                return false;
            }
        }
        return true;
    }

    //Metodo que comprueba si alguna casilla del grupo está hipotecada
    public boolean esGrupoHipotecado() {
        if(this.getMiembros().isEmpty()) {
            return false;
        }
        for (Casilla casilla : this.getMiembros()) {
            if (casilla.getHipotecada()) {
                return true;
            }
        }
        return false;
    }

    //Metodo que devuelve el precio de un tipo de edificio en el grupo
    public float getPrecioTipo(String EdificioTipo) {
        switch (EdificioTipo) {
            case "Casa":
                return this.getPrecioCasa();
            case "Hotel":
                return this.getPrecioHotel();
            case "Piscina":
                return this.getPrecioPiscina();
            case "Pista de deporte":
                return this.getPrecioPistaDeporte();
            default:
                return 0;
        }

    }

    //Metodo que calcula la rentabilidad del grupo
    public float rentabilidadgrupo(){
        float rentabilidad=0, gastos=0, generado=0;
        for(Casilla casilla: this.miembros){
            gastos+= casilla.gastosTotales();
            generado+= casilla.getGenerado();
        }
        rentabilidad= generado/gastos;
        return rentabilidad;
    }
}
