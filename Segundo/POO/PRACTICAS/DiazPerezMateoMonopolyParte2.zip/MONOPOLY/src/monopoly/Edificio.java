package monopoly;

import partida.*;
import java.util.ArrayList;

public class Edificio {
    private int identificador;
    private String tipo; // "Casa" o "Hotel"
    private Jugador propietario;
    private float precio;
    private Casilla casilla;
    private Grupo grupo;

    //Metódo constructor de edificio
    public Edificio(int identificador, String tipo, float precio, Casilla casilla, Grupo grupo, Jugador jugador) {
        this.identificador = identificador;
        this.tipo = tipo;
        this.precio = precio;
        this.casilla = casilla;
        this.grupo = grupo;
        this.propietario = jugador;
    }


    //Getters y Setters
    public int getIdentificador() {
        return identificador;
    }
    public void setIdentificador(int identificador) {
        this.identificador = identificador;
    }
    public String getTipo() {
        return tipo;
    }
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    public Jugador getPropietario() {
        return propietario;
    }
    public void setPropietario(Jugador propietario) {
        this.propietario = propietario;
    }
    public float getPrecio() {
        return precio;
    }
    public void setPrecio(float precio) {
        this.precio = precio;
    }
    public Casilla getCasilla() {
        return casilla;
    }
    public void setCasilla(Casilla casilla) {
        this.casilla = casilla;
    }
    public Grupo getGrupo() {
        return grupo;
    }
    public void setGrupo(Grupo grupo) {
        this.grupo = grupo;
    }

    //Metodo toString para imprimir la información del edificio
    @Override
    public String toString() {
        return "{\n" +
                "id: " + identificador + ",\n" +
                "tipo: " + tipo + ",\n" +
                "propietario: " + propietario.getNombre() + ",\n" +
                "casilla :" + casilla.getNombre() + ",\n" +
                "grupo: " + grupo.toString() + "\n" +
                "precio: " + precio + ",\n" +
                "}";
    }
}
