package monopoly;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class MonopolyETSE {
    // Metodo que realiza la lectura del archivo
    private ArrayList<String> lecturaFichero(String fichero) {
        // Lista para almacenar las lineas del fichero
        ArrayList<String> lista = new ArrayList<>();
        try{
            //  Abrimos el fichero y creamos el scanner q utilizaremos para leerlo linea a linea e ir insertandolas en la lista
            File f= new File(fichero);
            Scanner sc= new Scanner(f);
            while(sc.hasNextLine()){
                String linea= sc.nextLine();
                lista.add(linea);
            }
        }catch(FileNotFoundException e){
            System.out.println("Error...");
        }
        return lista;
    }
    public static void main(String[] args) {
        // Lectura del fichero de comandos
        ArrayList<String> listacomandos = new MonopolyETSE().lecturaFichero("comandos_2.txt");
        //creamos el menu y el scanner para leer los comandos pasados por terminal
        Menu menu = new Menu(listacomandos);
        Scanner scanner = new Scanner(System.in);
        while (true) {
            //bucle infinito hasta q el usuario decida salir
            System.out.print("Ingrese un comando (o 'salir' para terminar): ");
            String comando = scanner.nextLine();
            if (comando.equalsIgnoreCase("salir")) {
                break;
            }
            // llamamos al metodo del menu para analizar el comando ingresado
            menu.analizarComando(comando);
        }
    }
}
