package monopoly;

import partida.*;
import java.util.ArrayList;
import java.util.Iterator;

import static monopoly.Valor.*;


public class Casilla {

    //Atributos:
    private String nombre; //Nombre de la casilla
    private String tipo; //Tipo de casilla (Solar, Especial, Transporte, Servicios, Comunidad, Suerte y Impuesto).
    private float valor; //Valor de esa casilla (en la mayoría será valor de compra, en la casilla parking se usará como el bote).
    private int posicion; //Posición que ocupa la casilla en el tablero (entero entre 1 y 40).
    private Jugador duenho; //Dueño de la casilla (por defecto sería la banca).
    private Grupo grupo; //Grupo al que pertenece la casilla (si es solar).
    private boolean hipotecada; //Indica si la casilla está hipotecada o no.
    private float impuesto; //Cantidad a pagar por caer en la casilla: el alquiler en solares/servicios/transportes o impuestos.
    private float hipoteca; //Valor otorgado por hipotecar una casilla
    private float alquilerCasa;
    private float alquilerHotel;
    private float alquilerPiscina;
    private float alquilerPistaDeporte;
    private ArrayList<Avatar> avatares; //Avatares que están situados en la casilla.
    private ArrayList<Edificio> casas;
    private ArrayList<Edificio> hoteles;
    private ArrayList<Edificio> piscinas;
    private ArrayList<Edificio> pistasDeporte;
    private int visitada = 0;
    private float generado=0;

    //Constructores:
    public Casilla() {
    }//Parámetros vacíos

    /*Constructor para casillas tipo Solar, Servicios o Transporte:
     * Parámetros: nombre casilla, tipo (debe ser solar, serv. o transporte), posición en el tablero, valor y dueño.
     */
    public Casilla(String nombre, String tipo, int posicion, float valor, Jugador duenho) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.valor = valor;
        this.posicion = posicion;
        this.duenho = duenho;
        this.avatares = new ArrayList<>();
        this.casas = new ArrayList<>();
        this.hoteles = new ArrayList<>();
        this.piscinas = new ArrayList<>();
        this.pistasDeporte = new ArrayList<>();
        this.hipoteca= valor/2;
    }

    /*Constructor utilizado para inicializar las casillas de tipo IMPUESTOS.
     * Parámetros: nombre, posición en el tablero, impuesto establecido y dueño.
     */
    public Casilla(String nombre, int posicion, float impuesto, Jugador duenho) {
        this.nombre = nombre;
        this.tipo = "Impuesto";
        this.posicion = posicion;
        this.duenho = duenho;
        this.impuesto = impuesto;
        this.hipotecada = false;
        this.avatares = new ArrayList<>();
        this.casas = new ArrayList<>();
        this.hoteles = new ArrayList<>();
        this.piscinas = new ArrayList<>();
        this.pistasDeporte = new ArrayList<>();
    }

    /*Constructor utilizado para crear las otras casillas (Suerte, Caja de comunidad y Especiales):
     * Parámetros: nombre, tipo de la casilla (será uno de los que queda), posición en el tablero y dueño.
     */
    public Casilla(String nombre, String tipo, int posicion, Jugador duenho) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.posicion = posicion;
        this.duenho = duenho;
        this.hipotecada = false;
        this.avatares = new ArrayList<>();
        this.casas = new ArrayList<>();
        this.hoteles = new ArrayList<>();
        this.piscinas = new ArrayList<>();
        this.pistasDeporte = new ArrayList<>();
    }

    //Getters y setters:
    // Getter y Setter para nombre
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // Getter y Setter para tipo
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    // Getter y Setter para valor
    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    // Getter y Setter para posicion
    public int getPosicion() {
        return posicion;
    }

    public void setPosicion(int posicion) {
        this.posicion = posicion;
    }

    // Getter y Setter para duenho
    public Jugador getDuenho() {
        return duenho;
    }

    public void setDuenho(Jugador duenho) {
        this.duenho = duenho;
    }

    // Getter y Setter para grupo
    public Grupo getGrupo() {
        return grupo;
    }

    public void setGrupo(Grupo grupo) {
        this.grupo = grupo;
    }

    // Getter y Setter para impuesto
    public float getImpuesto() {
        return impuesto;
    }

    public void setImpuesto(float impuesto) {
        this.impuesto = impuesto;
    }

    // Getter y Setter para hipoteca
    public float getHipoteca() {
        return hipoteca;
    }

    public void setHipoteca(float hipoteca) {
        this.hipoteca = hipoteca;
    }

    // Getter y Setter para avatares
    public ArrayList<Avatar> getAvatares() {
        return avatares;
    }

    public void setAvatares(ArrayList<Avatar> avatares) {
        this.avatares = avatares;
    }

    public boolean getHipotecada() {
        return hipotecada;
    }

    public void setHipotecada(boolean hipotecada) {
        this.hipotecada = hipotecada;
    }

    public float getAlquilerCasa() {
        return alquilerCasa;
    }

    public void setAlquilerCasa(float alquilerCasa) {
        this.alquilerCasa = alquilerCasa;
    }

    // Getter y Setter para alquilerHotel
    public float getAlquilerHotel() {
        return alquilerHotel;
    }

    public void setAlquilerHotel(float alquilerHotel) {
        this.alquilerHotel = alquilerHotel;
    }

    // Getter y Setter para alquilerPiscina
    public float getAlquilerPiscina() {
        return alquilerPiscina;
    }

    public void setAlquilerPiscina(float alquilerPiscina) {
        this.alquilerPiscina = alquilerPiscina;
    }

    // Getter y Setter para alquilerPistaDeporte
    public float getAlquilerPistaDeporte() {
        return alquilerPistaDeporte;
    }

    public void setAlquilerPistaDeporte(float alquilerPistaDeporte) {
        this.alquilerPistaDeporte = alquilerPistaDeporte;
    }

    //Getter y Setter para casas
    public ArrayList<Edificio> getCasas() {
        return casas;
    }

    //Getters y Setter para hoteles
    public ArrayList<Edificio> getHoteles() {
        return hoteles;
    }

    public void setHoteles(ArrayList<Edificio> hoteles) {
        this.hoteles = hoteles;
    }

    //Getters y Setter para piscinas
    public ArrayList<Edificio> getPiscinas() {
        return piscinas;
    }

    public void setPiscinas(ArrayList<Edificio> hoteles) {
        this.piscinas = piscinas;
    }

    //Getters y Setter para piscinas
    public ArrayList<Edificio> getPistasDeporte() {
        return pistasDeporte;
    }

    public void setPistasDeporte(ArrayList<Edificio> pistasDeporte) {
        this.pistasDeporte = pistasDeporte;
    }



    //Getters y Setter para visitada
    public int getVisitada() {
        return visitada;
    }

    public void setVisitada(int visitada) {
        this.visitada = visitada;
    }

    //Getters y Setter para visitada
    public float getGenerado() {
        return generado;
    }

    public void getGenerado(float generado) {
        this.generado = generado;
    }


    //Método utilizado para añadir un avatar al array de avatares en casilla.
    public void anhadirAvatar(Avatar av) {
        avatares.add(av);
    }

    //Método utilizado para eliminar un avatar del array de avatares en casilla.
    public void eliminarAvatar(Avatar av) {
        avatares.remove(av);
    }


    // Metodo creado para contar el número de casillas sin Hipotecar de un tipo que tiene un Jugador
    // para poder calcular la cantidad de impuesto que le corresponde al inquilino
    public int contarCasillas(Jugador Duenho, String tipo) {
        int i = 0;
        for (Casilla c : Duenho.getPropiedades()) { //Recorremos todas las propiedades del dueño
            if (c.tipo.equals(tipo) && !c.hipotecada) { //Se cuenta si es del tipo correspondiente y no está hipotecada
                i++;
            }
        }
        return i;
    }

    //Método para contar las vueltas que ha dado un jugador al tablero
    public int contarVueltas(Jugador jugador) {
        return jugador.getVueltas();
    }


    /*Método para evaluar qué hacer en una casilla concreta. Parámetros:
     * - Jugador cuyo avatar está en esa casilla.
     * - La banca (para ciertas comprobaciones).
     * - El valor de la tirada: para determinar impuesto a pagar en casillas de servicios.
     * Valor devuelto: true en caso de ser solvente (es decir, de cumplir las deudas), y false
     * en caso de no cumplirlas.*/
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada) {
        float pago = 0; //Declaramos un float pago, que sera el precio a pagar, e i como un int para iterar
        int i = 0;
        if (!this.getDuenho().equals(banca) && !this.getDuenho().getNombre().equals(actual)) { //ALQUILER
            switch (this.getTipo()) { //Obtenemos el tipo de la casilla
                case "Servicios": //Si es de sevicios el precio varia según el número de servicios que tenga el dueño
                    i = contarCasillas(this.getDuenho(), "Servicios");
                    if (i == 1) {
                        pago = 4 * tirada * this.getImpuesto();
                    } else if (i == 2) {
                        pago = 10 * tirada * this.getImpuesto();
                    }
                    if (pago < actual.getFortuna()) return true; //Si tiene dinero para pagar, devuelve true
                    break;

                case "Solar": //Si es solar, el alquiler se obtine del impuesto fijo
                    pago = this.getImpuesto();
                    return actual.getFortuna() > pago; //Devuelve true si tiene dinero para pagar

                case "Transporte": //Si es de transporte, el precio varia según el número de transportes que tenga el dueño
                    i = contarCasillas(this.getDuenho(), "Transporte");
                    pago = i * this.getImpuesto();
                    if (pago < actual.getFortuna()) return true; //Devuelve true si tiene dinero para pagar
                    break;
            }
        } else if (this.getDuenho().equals(banca)) { //COMPRA
            switch (this.getTipo()) { //Obtenemos el tipo de la casilla
                case "Comunidad":
                case "Suerte":
                case "Especial":
                    return true; //Devuelve true, ya que estas casillas no se pueden comprar
                case "Servicios":
                case "Solar":
                case "Transporte":
                    return actual.getFortuna() > this.getValor(); //Devuelve true si tiene dinero para comprar
                case "Impuesto":
                    pago = this.getImpuesto();
                    return actual.getFortuna() > pago; //Devuelve true si tiene dinero para pagar
            }
        }
        return false; //En caso de que no pueda pagar devuelve false, indicando que es insolvente
    }

    /*Método usado para comprar una casilla determinada. Parámetros:
     * - Jugador que solicita la compra de la casilla.
     * - Banca del monopoly (es el dueño de las casillas no compradas aún).*/
    public void comprarCasilla(Jugador solicitante, Jugador banca) {
        ArrayList<Casilla> sinComprar = banca.getPropiedades(); //Las propiedades de la banca son las que no se han comprado todavia
        for (Casilla c : sinComprar) { //Recorremos las casillas sin comprar
            if (c.equals(this)) { //Si la casilla actual es igual a la que se quiere comprar
                if (evaluarCasilla(solicitante, banca, 0)) { //Si el jugador tiene suficiente dinero para comprarla pasa de ser de la banca al dueño
                    this.setDuenho(solicitante);
                    banca.eliminarPropiedad(this);
                    solicitante.sumarFortuna(-this.getValor());
                    solicitante.sumarGastos(this.getValor());
                    solicitante.anhadirPropiedad(this);
                    System.out.println("El jugador " + solicitante.getNombre() + " ha comprado la casilla " + nombre + ".\n");

                } else { //En caso de que no tenga imprimimos que no es posible
                    System.out.println("El jugador " + solicitante.getNombre() + " no tiene suficiente dinero para comprar la casilla " + nombre);
                }
                return; // Una vez evaluada la casilla actual no tiene sentido mirar las demás
            }
        }
    }

    /*Método para añadir valor a una casilla. Utilidad:
     * - Sumar valor a la casilla de parking.
     * - Sumar valor a las casillas de solar al no comprarlas tras cuatro vueltas de todos los jugadores.
     * Este método toma como argumento la cantidad a añadir del valor de la casilla.*/
    public void sumarValor(float suma) {
        if (this.getTipo().equals("Solar") && this.getDuenho().getNombre().equals("banca")) { //Si es una casilla Solar y no tiene dueño
            this.setValor(this.getValor() + suma);
            System.out.println("Valor de la casilla " + nombre + " duplicado a " + this.getValor() + "\n");

            //Si es la casilla de parking
        } else if (this.getTipo().equals("Especial") && this.getNombre().equals("Parking")) {
            this.setValor(this.getValor() + suma);
        }
    }

    //Método para listar los jugadores en casillas especiales (Cárcel y Parking).
    public String ListaJugadores(ArrayList<Avatar> avatares) {
        String mensaje = new String(); //Reservamos memoria para el String
        if (this.getTipo().equals("Especial") && this.getNombre().equals("Carcel")) {
            for (Avatar avatar : avatares) { //Concatenamos el mensaje con los jugadores encarcelados y sus tiradas en la cárcel
                mensaje = mensaje.concat("[" + avatar.getJugador().getNombre() + "," + avatar.getJugador().getTiradasCarcel() + "]");
            }
        }
        if (this.getTipo().equals("Especial") && this.getNombre().equals("Parking")) {
            mensaje = mensaje.concat("[");
            for (Avatar avatar : avatares) { //Concatenamos el mensaje con los jugadores en el parking
                mensaje = mensaje.concat(avatar.getJugador().getNombre() + ", ");
            }
            mensaje = mensaje.concat("]");
        }
        return mensaje;
    }

    /*Método para mostrar información sobre una casilla.
     * Devuelve una cadena con información específica de cada tipo de casilla.*/
    public String infoCasilla() {
        String mensaje = new String();
        //Diferenciamos la informacion que vamos a imprimir con un switch en funcion del tipo de casilla q estemos evaluando
        switch (this.getTipo()) {
            case "Impuesto":
                //en caso de que sea una casilla de impuesto imprimimos su tipo y el impuesto a pagar
                mensaje = "{\n\tTipo: " + this.getTipo() +
                        "\n\tA pagar: " + this.getImpuesto() +
                        "\n}";
                break;
            case "Especial":
                // en caso de que sea de tipo especial diferenciamos entre las distintas casillas especiales
                switch (this.getNombre()) {
                    case "Salida":
                        //en la salida printeamos el valor q se te suma al pasar por ella
                        mensaje = "{\n\tValor al pasar:" + this.getValor() +
                                "\n}";
                        break;
                    case "Carcel":
                        // para la carcel imprimimos el impuesto para salir de la carcel y los jugadores que hay en ella
                        mensaje = "{\n\tSalir: " + IMPUESTO_CARCEL +
                                "\n\tJugadores: " + this.ListaJugadores(this.avatares) +
                                "\n}";
                        break;
                    case "Parking":
                        // para el parking imprimimos el bote acumulado y los jugadores que hay en el parking
                        mensaje = "{\n\tBote: " + this.getValor() +
                                "\n\tJugadores: " + this.ListaJugadores(this.avatares) +
                                "\n}";
                        break;
                }
                break;
            case "Solar":
                // en caso de que sea una casilla solar imprimimos su tipo, grupo, propietario, valor, alquiler y demas valores asociados a las mejoras
                //en caso de que el propietario sea la banca no imprimimos su nombre
                if (this.getDuenho().getNombre().equals("banca")) {
                    mensaje = "{\n\tTipo: " + this.getTipo() +
                            "\n\tGrupo: " + this.getGrupo() +
                            "\n\tValor:" + this.getValor() +
                            "\n\tAlquiler:" + this.getImpuesto() +
                            "\n\tValor Hotel:" + this.getGrupo().getPrecioHotel() +
                            "\n\tValor Casa:" + this.getGrupo().getPrecioCasa() +
                            "\n\tValor Piscina:" + this.getGrupo().getPrecioPiscina() +
                            "\n\tValor Pista de deporte:" + this.getGrupo().getPrecioPistaDeporte() +
                            "\n\tAlquiler Casa:" + alquilerCasa +
                            "\n\tAlquiler Hotel:" + alquilerHotel +
                            "\n\tAlquiler Piscina:" + alquilerPiscina +
                            "\n\tAlquiler Pista de deporte:" + alquilerPistaDeporte +
                            "\n}";
                } else {
                    mensaje = "{\n\tTipo: " + this.getTipo() +
                            "\n\tGrupo: " + this.getGrupo() +
                            "\n\tPropietario:" + this.getDuenho().getNombre() +
                            "\n\tValor:" + this.getValor() +
                            "\n\tAlquiler:" + this.getImpuesto() +
                            "\n\tValor Hotel:" + this.getGrupo().getPrecioHotel() +
                            "\n\tValor Casa:" + this.getGrupo().getPrecioCasa() +
                            "\n\tValor Piscina:" + this.getGrupo().getPrecioPiscina() +
                            "\n\tValor Pista de deporte:" + this.getGrupo().getPrecioPistaDeporte() +
                            "\n\tAlquiler Casa:" + alquilerCasa +
                            "\n\tAlquiler Hotel:" + alquilerHotel +
                            "\n\tAlquiler Piscina:" + alquilerPiscina +
                            "\n\tAlquiler Pista de deporte:" + alquilerPistaDeporte +
                            "\n}";
                }
                break;
            case "Transporte":
            case "Servicios":
                // en caso de que sea una casilla de transporte o servicio imprimimos su tipo, propietario, valor y alquiler
                if (!this.getDuenho().getNombre().equals("banca")) {
                    mensaje = "{\n\tTipo: " + this.getTipo() +
                            "\n\tPropietario:" + this.getDuenho().getNombre() +
                            "\n\tValor:" + this.getValor() +
                            "\n\tAlquiler:" + this.getImpuesto() +
                            "\n}";
                } else {
                    mensaje = "{\n\tTipo: " + this.getTipo() +
                            "\n\tValor:" + this.getValor() +
                            "\n\tAlquiler:" + this.getImpuesto() +
                            "\n}";
                }
                break;
        }
        return mensaje;
    }

    /* Método para mostrar información de una casilla en venta.
     * Valor devuelto: texto con esa información.
     */
    public String casEnVenta() {
        String mensaje = new String(); //Reservamos memoria para el String
        if (this.getDuenho().getFortuna() == FORTUNA_BANCA) { //Si tiene el dueño tiene fortuna infinita, entonces es la banca
            switch (this.getTipo()) { //Obtenemos un tipo de casilla en venta y la imprimimos
                case "Solar":
                    mensaje = "{\n\tNombre:" + this.getNombre() +
                            "\n\tTipo: " + this.getTipo() +
                            "\n\tGrupo: " + this.getGrupo() +
                            "\n\tValor:" + this.getValor() +
                            "\n}";
                    break;
                case "Transporte":
                case "Servicios":
                    mensaje = "{\n\tNombre:" + this.getNombre() +
                            "\n\tTipo: " + this.getTipo() +
                            "\n\tValor:" + this.getValor() +
                            "\n}";
                    break;
            }
            return mensaje;
        }
        return null;
    }

    //Método equals para comparar dos casillas (se consideran iguales si tienen el mismo nombre y posición).
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Casilla casilla = (Casilla) obj;
        return (nombre == casilla.nombre) && (posicion == casilla.posicion);
    }

    //Método para pagar el alquiler/impuesto de una casilla. Parámetros:
    // - Dueño de la casilla.
    // - Jugador moroso que debe pagar el alquiler/impuesto.
    public void pagarDeudas(Jugador duenho, Jugador moroso, int valorTirada){
        if(valorTirada < 0){
            valorTirada = -valorTirada;
        }
        switch (getTipo()) {
            case "Solar":
                moroso.sumarFortuna(-this.impuestoTotal()); //El moroso resta su fortuna para pagar
                moroso.sumarGastos(this.impuestoTotal()); //El moroso suma sus gastos por el pago realizado
                moroso.sumaralquileres(this.impuestoTotal());
                duenho.sumarFortuna(this.impuestoTotal()); //El dueño suma su fortuna al recibir el pago
                duenho.sumarCobrosAlquileres(this.impuestoTotal());
                this.sumargenerado(this.impuestoTotal());

                break;

            case "Transporte":
                moroso.sumarFortuna(-contarCasillas(duenho, "Transporte") * this.getImpuesto());
                moroso.sumarGastos(contarCasillas(duenho, "Transporte") * this.getImpuesto());
                moroso.sumaralquileres(contarCasillas(duenho, "Transporte") * this.getImpuesto());
                duenho.sumarFortuna(contarCasillas(duenho, "Transporte") * this.getImpuesto());
                duenho.sumarCobrosAlquileres(contarCasillas(duenho, "Transporte") * this.getImpuesto());
                this.sumargenerado(contarCasillas(duenho, "Transporte") * this.getImpuesto());
                break;

            case "Servicios":
                int numCasillas = contarCasillas(duenho, "Servicios");
                if (numCasillas == 1) { //Si el dueño tiene un servicio se paga 4 veces la tirada por el impuesto
                    moroso.sumarFortuna(-4 * valorTirada * this.getImpuesto());
                    moroso.sumarGastos(4 * valorTirada * this.getImpuesto());
                    moroso.sumaralquileres(4 * valorTirada * this.getImpuesto());
                    duenho.sumarFortuna(4 * valorTirada * this.getImpuesto());
                    duenho.sumarCobrosAlquileres(4 * valorTirada * this.getImpuesto());
                    this.sumargenerado(4 * valorTirada * this.getImpuesto());
                } else if (numCasillas == 2) { //Si el dueño tiene dos servicios se paga 10 veces la tirada por el impuesto
                    moroso.sumarFortuna(-10 * valorTirada * this.getImpuesto());
                    moroso.sumarGastos(10 * valorTirada * this.getImpuesto());
                    moroso.sumaralquileres(10* valorTirada * this.getImpuesto()); //
                    duenho.sumarFortuna(10 * valorTirada * this.getImpuesto());
                    duenho.sumarCobrosAlquileres(10 * valorTirada * this.getImpuesto()); // El duenho suma su cuenta de cobros
                    this.sumargenerado(10 * valorTirada * this.getImpuesto());
                }
                break;
            case "Impuesto":
                moroso.sumarFortuna(-this.getImpuesto()); //El moroso resta su fortuna para pagar
                moroso.sumarGastos(this.getImpuesto()); //El moroso suma sus gastos por el pago realizado
                moroso.sumarimpuestos(this.getImpuesto()); // El moroso suma sus impuestos pagados
                break;

                /*
            case "Parking":
                moroso.sumarFortuna(-this.getImpuesto()); //El moroso resta su fortuna para pagar
                moroso.sumarGastos(this.getImpuesto()); //El moroso suma sus gastos por el pago realizado
                moroso.sumarimpuestos(this.getImpuesto()); // El moroso suma sus impuestos pagados
                break;*/
        }

    }

    //Metodo privado para comprobar que el avatar del duenho está en la propiedad a edificar
    private Boolean esMismoAvatar() {
        //Recorremos los avatares en la casilla y si encuentra el del dueño devuelve true
        for (Avatar av : avatares) {
            if (av.equals(this.getDuenho().getAvatar())) {
                return true;
            }
        }
        return false;
    }

    //Metodo para construir un edificio en una casilla al comprar todo el grupo
    public void construirEdificio(String tipoEdificio, int id) {
        //Comprobamos que no se pueda edificar más en la casilla o el grupo y que es un Solar
        if (this.tipo.equals("Solar") && this.grupo.esGrupoCompleto()) {
            System.out.println("No se puede edificar ningún edificio más en esta casilla ni en el grupo al que pertence.\n");
            return;
        } else if (this.tipo.equals("Solar") && this.esCasillaCompleta()) {
            System.out.println("No se puede edificar ningún edificio más en esta casilla.\n");
            return;

        //Comprobamos que ninguna casilla del grupo este hipotecada
        } else if(this.tipo.equals("Solar") && this.grupo.esGrupoHipotecado() && esMismoAvatar()) {
            System.out.println("No se puede edificar en una casilla hipotecada o si una casilla del grupo está hipotecada.\n");
            return;
        }

        //Comprobamos que sea un solar y que el dueño sea el propietario de la casilla, y si tiene todo el grupo
        if (!(this.tipo.equals("Solar") && esMismoAvatar() && this.grupo.esDuenhoGrupo(this.duenho))) {
            System.out.println("No se cumplen las condiciones para edificar.\n");
            return;
        }

        //Comprobamos que el jugador tenga suficiente fortuna para edificar
        if (this.grupo.getPrecioTipo(tipoEdificio) > this.duenho.getFortuna()) {
            System.out.println("La fortuna de " + this.duenho.getNombre() + " no es suficiente para edificar un/a " + tipoEdificio + " en la casilla " + this.getNombre() + ".\n");
            return;
        }

        //Obtenemos el id del edificio a construir y construimos el edificio segun el tipo
        // Le aplicamos el método Capitalize al tipo del Edificio para que CASA o casa también se procesen como Casa
        switch (tipoEdificio.substring(0,1).toUpperCase()+tipoEdificio.substring(1).toLowerCase()) {
            case "Casa":
                if (this.cabeEdificio("Casa")) { //Comprobamos que no haya 4 casas y no haya hotel
                    Edificio edificio = new Edificio(id, tipoEdificio, this.grupo.getPrecioCasa(), this, this.grupo, this.duenho);
                    this.casas.add(edificio);                                   //Añadimos la casa al array de casas
                    this.getDuenho().sumarFortuna(-edificio.getPrecio());       //Restamos el precio del hotel a la fortuna del dueño
                    this.getDuenho().sumarGastos(edificio.getPrecio());         //Sumamos el precio del hotel a los gastos del dueño
                    this.getDuenho().anhadirEdificio(edificio);                 //Añadimos el edificio al array de edificios del dueño
                    System.out.println("Se ha edificado un " + tipoEdificio + " en " + this.getNombre() + ". La fortuna de " + this.getDuenho().getNombre() + " se reduce en " + edificio.getPrecio() + ".\n");

                } else {
                    System.out.println("No se puede edificar una casa, ya hay 4 y la casilla " + this.nombre + " está llena\n");
                }
                break;

            case "Hotel":
                if (this.cabeEdificio("Hotel")) { //Comprobamos que haya 4 casas y no haya hotel
                    Edificio edificio = new Edificio(id, tipoEdificio, this.grupo.getPrecioHotel(), this, this.grupo, this.duenho);
                    this.hoteles.add(edificio);                                //Añadimos el hotel al array de hoteles
                    this.venderEdificio("Casas", 4);        //Vendemos las 4 casas para edificar el hotel
                    this.getDuenho().sumarFortuna(-edificio.getPrecio());      //Restamos el precio del hotel a la fortuna del dueño
                    this.getDuenho().sumarGastos(edificio.getPrecio());        //Sumamos el precio del hotel a los gastos del dueño
                    this.getDuenho().anhadirEdificio(edificio);                //Añadimos el edificio al array de edificios del dueño
                    System.out.println("Se ha edificado un " + tipoEdificio + " en " + this.getNombre() + ". La fortuna de " + this.getDuenho().getNombre() + " se reduce en " + edificio.getPrecio() + ".\n");

                } else {
                    System.out.println("No se puede edificar un hotel, ya que no se disponen 4 casas.\n");
                }
                break;

            case "Piscina":
                if (this.cabeEdificio("Piscina")) { //Comprobamos que haya 4 casas y no haya hotel
                    Edificio edificio = new Edificio(id, tipoEdificio, this.grupo.getPrecioPiscina(), this, this.grupo, this.duenho);
                    this.piscinas.add(edificio);                              //Añadimos la piscina al array de piscinas
                    this.getDuenho().sumarFortuna(-edificio.getPrecio());     //Restamos el precio del hotel a la fortuna del dueño
                    this.getDuenho().sumarGastos(edificio.getPrecio());       //Sumamos el precio del hotel a los gastos del dueño
                    this.getDuenho().anhadirEdificio(edificio);               //Añadimos el edificio al array de edificios del dueño
                    System.out.println("Se ha edificado un " + tipoEdificio + " en " + this.getNombre() + ". La fortuna de " + this.getDuenho().getNombre() + " se reduce en " + edificio.getPrecio() + ".\n");

                } else {
                    System.out.println("No se puede edificar una piscina, ya que no se dispone de un hotel y una piscina en la casilla " + this.getNombre() + ".\n");
                }
                break;
            case "Pista de deporte": //Para q lo pillen los comandos
                if (this.cabeEdificio("Pista de deporte")) { //Comprobamos que haya 4 casas y no haya hotel
                    Edificio edificio = new Edificio(id, tipoEdificio, this.grupo.getPrecioPistaDeporte(), this, this.grupo, this.duenho);
                    this.pistasDeporte.add(edificio);                         //Añadimos la pista de deporte al array de pistas de deporte
                    this.getDuenho().sumarFortuna(-edificio.getPrecio());     //Restamos el precio del hotel a la fortuna del dueño
                    this.getDuenho().sumarGastos(edificio.getPrecio());       //Sumamos el precio del hotel a los gastos del dueño
                    this.getDuenho().anhadirEdificio(edificio);               //Añadimos el edificio al array de edificios del dueño
                    System.out.println("Se ha edificado un " + tipoEdificio + " en " + this.getNombre() + ". La fortuna de " + this.getDuenho().getNombre() + " se reduce en " + edificio.getPrecio() + ".\n");

                } else {
                    System.out.println("No se puede edificar una pista de deporte, ya que no se dispone de un hotel y una piscina en la casilla " + this.getNombre() + ".\n");
                }
                break;
            default:
                System.out.println("No se existen edificios de tipo " + tipoEdificio + ".\n");
                break;
        }
    }

    //Metodo para comprobar que una casilla está completa (tiene todos los edificios posibles)
    public boolean esCasillaCompleta() {
        // Una casilla está completa si tiene 1 pista de deporte
        return this.numTipo("Pista de deporte") == 1;
    }


    //Método para saber si se puede construir un edificio más de un tipo tipoEdificio en una casilla
    //(NO COMPARA DINERO, SOLO CAPACIDAD)
    public boolean cabeEdificio(String tipoEdificio) {
        switch (tipoEdificio) {
            case "Casa":
                return (this.numTipo("Casa") < 4);
            case "Hotel":
                return (this.numTipo("Casa") == 4 && this.numTipo("Hotel") < 1);
            case "Piscina":
                return (this.numTipo("Piscina") < 1 && this.numTipo("Hotel") == 1);
            case "Pista de deporte":
                return (this.numTipo("Pista de deporte") < 1 && this.numTipo("Piscina") == 1 && this.numTipo("Hotel") == 1);
            default:
                return false;
        }
    }

    // Método para vender edificios de una casilla
    // · "Casas" Utilizado para vender tantas numCasas como se indiquen
    // "Casa", "Hotel", "Piscina" o "Pista de deporte" para vender un único edificio de ese tipo
    public void venderEdificio(String tipoEdificio, int numCasas) {
        // Obtenemos el tipo del edificio a vender
        // Le aplicamos el método Capitalize al tipo del Edificio para que CASA o casa también se procesen como Casa
        switch (tipoEdificio.substring(0,1).toUpperCase()+tipoEdificio.substring(1).toLowerCase()) {
            case "Casas":
                //Si hay menos casas de las que se quieren vender
                if (this.numTipo("Casa") < numCasas) {
                    System.out.println("La casilla " + this.getNombre() + " no tiene tantas casas para vender.\n");
                    return;
                }

                // Vendemos el número de casas indicado
                int numCasasInicial = numCasas;
                //Creamos un iterator, para poder eliminar elementos del arraylist de casas
                Iterator<Edificio> casasIt = casas.iterator();
                while (casasIt.hasNext() && numCasas > 0) {
                    Edificio casa = casasIt.next();
                    casasIt.remove();
                    numCasas--;
                }

                //Repetimos el proceso para eliminar las casas del array de edificios del dueño
                numCasas = numCasasInicial;
                Iterator<Edificio> duenhoCasasIt = duenho.getEdificios().iterator();
                while (duenhoCasasIt.hasNext() && numCasas > 0) {
                    Edificio casa = duenhoCasasIt.next();
                    if (casa.getCasilla().equals(this) && casa.getTipo().equals("Casa")) {
                        duenhoCasasIt.remove();
                        numCasas--;
                    }
                }

                // Si hay un hotel, no hay que pagarle el precio de las casas porque se sustituyen
                if (this.numTipo("Hotel") == 0){ // Si no hay hotel, se venden las casas normalmente y se paga al jugador
                    duenho.sumarFortuna(numCasasInicial * this.grupo.getPrecioCasa());
                    System.out.println(numCasasInicial + " casas en " + this.getNombre() + " han sido vendidas. La fortuna de " + this.duenho.getNombre() + " aumenta en " + (numCasasInicial * this.grupo.getPrecioCasa()) + ".\n");
                }
                break;

            case "Casa":
                //Se comprueba si hay casas a vender
                if (this.numTipo("Casa") == 0) {
                    System.out.println("La casilla +" + this.getNombre() + " no tiene ninguna casa para vender.");
                } else {
                    this.duenho.eliminarEdificio(casas.getFirst());         //Obtiene la primera casa y la elimina del dueño
                    this.casas.removeFirst();                               //Elimina la casa del array de casas de la casilla
                    this.duenho.sumarFortuna(this.grupo.getPrecioCasa());   //Suma el precio de la casa a la fortuna del dueño
                    System.out.println("Una casa " + this.getNombre() + " ha sido vendida. La fortuna de " + this.duenho.getNombre() + " aumenta en " + this.grupo.getPrecioCasa() + ".\n");
                }
                break;

            case "Hotel":
                //Se comprueba si hay hoteles a vender
                if (this.numTipo("Hotel") == 0) {
                    System.out.println("La casilla +" + this.getNombre() + " no tiene ningún hotel para vender.");
                    return;
                } else {
                    this.duenho.eliminarEdificio(hoteles.getFirst());       //Obtiene el primer hotel y lo elimina del dueño
                    hoteles.removeFirst();                                  //Elimina el hotel del array de casas de la casilla
                    duenho.sumarFortuna(this.grupo.getPrecioHotel());       //Suma el precio del hotel a la fortuna del dueño
                    System.out.println("Un hotel en " + this.getNombre() + " ha sido vendido. La fortuna de " + this.duenho.getNombre() + " aumenta en " + this.grupo.getPrecioHotel() + ".\n");
                    //Se vende la piscina asociada al hotel si existe
                    if (this.numTipo("Piscina") > 0) {
                        venderEdificio("Piscina", 0);
                        System.out.println(("También se ha vendido la piscina asociada al hotel.\n"));
                    }
                }
                break;

            case "Piscina":
                //Se comprueba si hay hoteles a vender
                if (this.numTipo("Piscina") == 0) {
                    System.out.println("La casilla +" + this.getNombre() + " no tiene ninguna piscina para vender.");
                    return;
                }else {
                    this.duenho.eliminarEdificio(piscinas.getFirst());      //Obtiene la primera piscina y la elimina del dueño
                    piscinas.removeFirst();                                 //Elimina la piscina del array de piscinas de la casilla
                    duenho.sumarFortuna(this.grupo.getPrecioPiscina());     //Suma el precio de la piscina a la fortuna del dueño
                    System.out.println("Una piscina en " + this.getNombre() + " ha sido vendida. La fortuna de " + this.duenho.getNombre() + " aumenta en " + this.grupo.getPrecioPiscina() + ".\n");
                    //Se vende la pista de deporte asociada a la piscina si existe
                    if (this.numTipo("Pista de deporte") > 0) {
                        venderEdificio("Pista de deporte", 0);
                        System.out.println(("También se ha vendido la pista de deporte asociada a la piscina.\n"));
                    }
                }
                break;

            case "Pista de deporte":
                //Se comprueba si hay hoteles a vender
                if (this.numTipo("Pista de deporte") == 0) {
                    System.out.println("La casilla +" + this.getNombre() + " no tiene ninguna pista de deporte para vender.");
                    return;
                }else {
                    this.duenho.eliminarEdificio(pistasDeporte.getFirst());   //Obtiene la primera pista de deporte y la elimina del dueño
                    pistasDeporte.removeFirst();                              //Elimina la pista de deporte del array de pistas de deporte de la casilla
                    duenho.sumarFortuna(this.grupo.getPrecioPistaDeporte());  //Suma el precio de la pista de deporte a la fortuna del dueño
                    System.out.println("Una pista de deporte en " + this.getNombre() + " ha sido vendida. La fortuna de " + this.duenho.getNombre() + " aumenta en " + this.grupo.getPrecioPistaDeporte() + ".\n");
                }
                break;

            default:
                break;
        }
    }

    //Metodo que crea un arraylist con todos los edificios de una casilla, recorriendo cada uno de los arrays
    public ArrayList<Edificio> edificiosCasilla() {
        ArrayList<Edificio> Edificios = new ArrayList<>();
        for (Edificio casa : casas) {
            Edificios.add(casa);
        }
        for (Edificio hotel : hoteles) {
            Edificios.add(hotel);
        }
        for (Edificio piscina : piscinas) {
            Edificios.add(piscina);
        }
        for (Edificio pistaDeporte : pistasDeporte) {
            Edificios.add(pistaDeporte);
        }
        return Edificios;
    }

    //Metodo que devuelve el número de edificios de un tipo determinado en la casilla
    public int numTipo(String tipo) {
        switch (tipo) {
            case "Casa":
                return this.casas.size();
            case "Hotel":
                return this.hoteles.size();
            case "Piscina":
                return this.piscinas.size();
            case "Pista de deporte":
                return this.pistasDeporte.size();
            default:
                return -1;
        }
    }

    //Metodo para hipotecar una propiedad del tipo "Solar", "Transporte" o "Servicios"
    public void hipotecar() {
        //Comprobamos que la casilla de tipo "Solar" no tenga edificios construidos, y si no es así se indican cuales debe vender
        if(this.tipo.equals("Solar")) {
            if (this.edificiosCasilla().size() > 0) {
                System.out.println("No se puede hipotecar la casilla " + nombre + " porque tiene edificios construidos.\n");
                if (numTipo("Casa") > 0) {
                    System.out.println("Casas construidas: " + numTipo("Casa") + "\n");
                }
                if (numTipo("Hotel") > 0) {
                    System.out.println("Hoteles construidos: " + numTipo("Hotel") + "\n");
                }
                if (numTipo("Piscina") > 0) {
                    System.out.println("Piscinas construidas: " + numTipo("Piscina") + "\n");
                }
                if (numTipo("Pista de deporte") > 0) {
                    System.out.println("Pistas de deporte construidas: " + numTipo("Pista de deporte") + "\n");
                }
                return;
            }
        }
        // Si es Transporte, Servicios o Solar (sin edificios, si tiene edificios ya habría salido de la función)
        // Se procede a validad la hipoteca
        else if (this.tipo.equals("Transporte") || this.tipo.equals("Servicios") || this.tipo.equals("Solar")) {
            if (this.hipotecada) { // Se comprueba que no esté hipotecada de antes
                System.out.println("La casilla " + nombre + " ya está hipotecada.\n");
                return;
            }
            else {
                this.hipotecada = true;                         //Cambiamos el estado de la hipoteca
                this.duenho.sumarFortuna(this.getHipoteca());   //Sumamos la hipoteca a la fortuna del dueño
                if(this.tipo.equals("Solar")) {
                    System.out.println(this.duenho.getNombre() + " recibe " + hipoteca + " por la hipoteca de " + nombre + ". No puede recibir alquileres ni edificar en el grupo " + grupo);
                }
                else{
                    System.out.println(this.duenho.getNombre() + " recibe " + hipoteca + " por la hipoteca de " + nombre + ". No puede recibir alquileres de la casilla, si tiene más propiedades del mismo tipo el alquiler total disminuye.");
                }
            }
        }
    }

    //Metodo para deshipotecar una propiedad del tipo "Solar", "Transporte" o "Servicios"
    public void deshipotecar() {
        //Se comprueba que no este deshipotecada de antes
        if (!hipotecada) {
            System.out.println("La casilla " + nombre + " no está hipotecada.\n");
            return;
        }
        else {
            //Comprobamos que el dueño tenga suficiente fortuna para deshipotecar
            if (duenho.getFortuna() < hipoteca) {
                System.out.println("El jugador " + duenho.getNombre() + " no tiene suficiente fortuna para deshipotecar la casilla " + nombre + ".\n");
                return;
            }
            hipotecada = false;                 //Cambiamos el estado de la hipoteca
            duenho.sumarFortuna(-hipoteca);     //Restamos la hipoteca a la fortuna del dueño
            duenho.sumarGastos(hipoteca);       //Sumamos la hipoteca a los gastos del dueño
            System.out.println(duenho.getNombre() + " paga " + hipoteca + " para deshipotecar la casilla " + nombre + (grupo != null && grupo.esDuenhoGrupo(getDuenho()) ? ". Ahora puede recibir alquileres y edificar en el grupo " + grupo.getColorGrupo() + "." : ". Ahora puede reibir alquileres de la casilla."));
        }
    }

    //Metodo para designar los alquileres de un Solar desde el inicio de la partida
    public void ajustarAlquileres(float casa, float hotel, float piscina, float pista) {
        this.alquilerCasa = casa;
        this.alquilerHotel = hotel;
        this.alquilerPiscina = piscina;
        this.alquilerPistaDeporte = pista;
    }

    //Metodo que suma una visita a la casilla
    public void sumarvisitada() {
        this.visitada++;
    }

    //Metodo que calcula los gastos totales de una casilla, sumando su valor y el precio de los edificios construidos
    public float gastosTotales() {
        float total = getValor();
        for (Edificio edificio : edificiosCasilla()) {
            total += edificio.getPrecio();
        }
        return total;
    }

    //Metodo que suma el dinero generado por una casilla
    public void sumargenerado(float generado) {
        this.generado += generado;
    }

    //Metodos que calculan el impuesto total de una casilla, sumando el impuesto base y los alquileres de los edificios
    public float impuestoTotal(){
        float total = this.impuesto;
        //Comprobamos si hay edificios en la casilla y sumamos su alquiler correspondiente a total
        if(this.edificiosCasilla().size()>0){
            for(Edificio e:this.edificiosCasilla()){
                switch (e.getTipo()){
                    case "Casa":
                        total+=this.alquilerCasa;
                        break;
                    case "Hotel":
                        total+=this.alquilerHotel;
                        break;
                    case "Piscina":
                        total+=this.alquilerPiscina;
                        break;
                    case "Pista de deporte":
                        total+=this.alquilerPistaDeporte;
                        break;
                }
            }
        }

        return total;
    }
}

