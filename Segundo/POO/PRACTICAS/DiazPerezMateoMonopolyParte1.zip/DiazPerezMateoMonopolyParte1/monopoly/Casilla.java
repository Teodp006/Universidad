package monopoly;

import partida.*;
import java.util.ArrayList;

import static monopoly.Valor.FORTUNA_BANCA;
import static monopoly.Valor.IMPUESTO_CARCEL;


public class Casilla {

    //Atributos:
    private String nombre; //Nombre de la casilla
    private String tipo; //Tipo de casilla (Solar, Especial, Transporte, Servicios, Comunidad, Suerte y Impuesto).
    private float valor; //Valor de esa casilla (en la mayoría será valor de compra, en la casilla parking se usará como el bote).
    private int posicion; //Posición que ocupa la casilla en el tablero (entero entre 1 y 40).
    private Jugador duenho; //Dueño de la casilla (por defecto sería la banca).
    private Grupo grupo; //Grupo al que pertenece la casilla (si es solar).
    private float impuesto; //Cantidad a pagar por caer en la casilla: el alquiler en solares/servicios/transportes o impuestos.
    private float hipoteca; //Valor otorgado por hipotecar una casilla
    private ArrayList<Avatar> avatares; //Avatares que están situados en la casilla.


    //Constructores:
    public Casilla() {
    }//Parámetros vacíos

    /*Constructor para casillas tipo Solar, Servicios o Transporte:
     * Parámetros: nombre casilla, tipo (debe ser solar, serv. o transporte), posición en el tablero, valor y dueño.
     */
    public Casilla(String nombre, String tipo, int posicion, float valor, Jugador duenho) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.valor = valor;
        this.posicion = posicion;
        this.duenho = duenho;
        this.avatares = new ArrayList<>();
    }

    /*Constructor utilizado para inicializar las casillas de tipo IMPUESTOS.
     * Parámetros: nombre, posición en el tablero, impuesto establecido y dueño.
     */
    public Casilla(String nombre, int posicion, float impuesto, Jugador duenho) {
        this.nombre = nombre;
        this.tipo = "Impuesto";
        this.posicion = posicion;
        this.duenho = duenho;
        this.impuesto = impuesto;
        this.avatares = new ArrayList<>();
    }

    /*Constructor utilizado para crear las otras casillas (Suerte, Caja de comunidad y Especiales):
     * Parámetros: nombre, tipo de la casilla (será uno de los que queda), posición en el tablero y dueño.
     */
    public Casilla(String nombre, String tipo, int posicion, Jugador duenho) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.posicion = posicion;
        this.duenho = duenho;
        this.avatares = new ArrayList<>();
    }

    //Getters y setters:
    // Getter y Setter para nombre
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // Getter y Setter para tipo
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    // Getter y Setter para valor
    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    // Getter y Setter para posicion
    public int getPosicion() {
        return posicion;
    }

    public void setPosicion(int posicion) {
        this.posicion = posicion;
    }

    // Getter y Setter para duenho
    public Jugador getDuenho() {
        return duenho;
    }

    public void setDuenho(Jugador duenho) {
        this.duenho = duenho;
    }

    // Getter y Setter para grupo
    public Grupo getGrupo() {
        return grupo;
    }

    public void setGrupo(Grupo grupo) {
        this.grupo = grupo;
    }

    // Getter y Setter para impuesto
    public float getImpuesto() {
        return impuesto;
    }

    public void setImpuesto(float impuesto) {
        this.impuesto = impuesto;
    }

    // Getter y Setter para hipoteca
    public float getHipoteca() {
        return hipoteca;
    }

    public void setHipoteca(float hipoteca) {
        this.hipoteca = hipoteca;
    }

    // Getter y Setter para avatares
    public ArrayList<Avatar> getAvatares() {
        return avatares;
    }

    public void setAvatares(ArrayList<Avatar> avatares) {
        this.avatares = avatares;
    }

    //Método utilizado para añadir un avatar al array de avatares en casilla.
    public void anhadirAvatar(Avatar av) {
        avatares.add(av);
    }

    //Método utilizado para eliminar un avatar del array de avatares en casilla.
    public void eliminarAvatar(Avatar av) {
        avatares.remove(av);
    }

    //Metodo creado para contar el número de casillas de un tipo que tiene un Jugador
    //Utilizado para calcular el alquiler en transportes y servicios
    public int contarCasillas(Jugador Duenho, String tipo) {
        int i = 0;
        for (Casilla c : Duenho.getPropiedades()) { //Recorremos todas las propiedades del dueño
            if (c.tipo.equals(tipo)) { //Si coincide con el tipo dado incrementa i
                i++;
            }
        }
        return i;
    }

    //Método para contar las vueltas que ha dado un jugador al tablero
    public int contarVueltas(Jugador jugador) {
        return jugador.getVueltas();
    }


    /*Método para evaluar qué hacer en una casilla concreta. Parámetros:
     * - Jugador cuyo avatar está en esa casilla.
     * - La banca (para ciertas comprobaciones).
     * - El valor de la tirada: para determinar impuesto a pagar en casillas de servicios.
     * Valor devuelto: true en caso de ser solvente (es decir, de cumplir las deudas), y false
     * en caso de no cumplirlas.*/
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada) {
        float pago = 0; //Declaramos un float pago, que sera el precio a pagar, e i como un int para iterar
        int i = 0;
        if (!this.getDuenho().equals(banca) && !this.getDuenho().getNombre().equals(actual)) { //ALQUILER
            switch (this.getTipo()) { //Obtenemos el tipo de la casilla
                case "Servicios": //Si es de sevicios el precio varia según el número de servicios que tenga el dueño
                    i = contarCasillas(this.getDuenho(), "Servicios");
                    if (i == 1) {
                        pago = 4 * tirada * this.getImpuesto();
                    } else if (i == 2) {
                        pago = 10 * tirada * this.getImpuesto();
                    }
                    if (pago < actual.getFortuna()) return true; //Si tiene dinero para pagar, devuelve true
                    break;

                case "Solar": //Si es solar, el alquiler se obtine del impuesto fijo
                    pago = this.getImpuesto();
                    return actual.getFortuna() > pago; //Devuelve true si tiene dinero para pagar

                case "Transporte": //Si es de transporte, el precio varia según el número de transportes que tenga el dueño
                    i = contarCasillas(this.getDuenho(), "Transporte");
                    pago = i * this.getImpuesto();
                    if (pago < actual.getFortuna()) return true; //Devuelve true si tiene dinero para pagar
                    break;
            }
        } else if (this.getDuenho().equals(banca)) { //COMPRA
            switch (this.getTipo()) { //Obtenemos el tipo de la casilla
                case "Comunidad":
                case "Suerte":
                case "Especial":
                    return true; //Devuelve true, ya que estas casillas no se pueden comprar
                case "Servicios":
                case "Solar":
                case "Transporte":
                    return actual.getFortuna() > this.getValor(); //Devuelve true si tiene dinero para comprar
                case "Impuesto":
                    pago = this.getImpuesto();
                    return actual.getFortuna() > pago; //Devuelve true si tiene dinero para pagar
            }
        }
        return false; //En caso de que no pueda pagar devuelve false, indicando que es insolvente
    }

    /*Método usado para comprar una casilla determinada. Parámetros:
     * - Jugador que solicita la compra de la casilla.
     * - Banca del monopoly (es el dueño de las casillas no compradas aún).*/
    public void comprarCasilla(Jugador solicitante, Jugador banca) {
        ArrayList<Casilla> sinComprar = banca.getPropiedades(); //Las propiedades de la banca son las que no se han comprado todavia
        for (Casilla c : sinComprar) { //Recorremos las casillas sin comprar
            if (c.equals(this)) { //Si la casilla actual es igual a la que se quiere comprar
                if (evaluarCasilla(solicitante, banca, 0)) { //Si el jugador tiene suficiente dinero para comprarla pasa de ser de la banca al dueño
                    this.setDuenho(solicitante);
                    banca.eliminarPropiedad(this);
                    solicitante.sumarFortuna(-this.getValor());
                    solicitante.sumarGastos(this.getValor());
                    solicitante.anhadirPropiedad(this);
                } else { //En caso de que no tenga imprimimos que no es posible
                    System.out.println("El jugador" + solicitante.getNombre() + " no tiene suficiente dinero para comprar la casilla " + this.getNombre());
                }
                return; // Una vez evaluada la casilla actual no tiene sentido mirar las demás
            }
        }
    }

    /*Método para añadir valor a una casilla. Utilidad:
     * - Sumar valor a la casilla de parking.
     * - Sumar valor a las casillas de solar al no comprarlas tras cuatro vueltas de todos los jugadores.
     * Este método toma como argumento la cantidad a añadir del valor de la casilla.*/
    public void sumarValor(float suma) {
        if (this.getTipo().equals("Solar") && !this.getDuenho().getNombre().equals("banca")) { //Si es una casilla Solar y no tiene dueño
            boolean todosCumplen = true; //Variable para comprobar si todos los jugadores cumplen la condición

            for(Avatar av: avatares){
                Jugador jugador = av.getJugador();
                if (this.contarVueltas(jugador) < 4) {
                    todosCumplen = false;
                    break;
                }
            }

            if (todosCumplen) {
                this.setValor(this.getValor() + suma);
            }
            //Si es la casilla de parking
        } else if (this.getTipo().equals("Especial") && this.getNombre().equals("Parking")) {
            this.setValor(this.getValor() + suma);
        }
    }

   //Método para listar los jugadores en casillas especiales (Cárcel y Parking).
    public String ListaJugadores(ArrayList<Avatar> avatares){
        String mensaje = new String(); //Reservamos memoria para el String
        if (this.getTipo().equals("Especial") && this.getNombre().equals("Carcel")) {
            for(Avatar avatar:avatares){ //Concatenamos el mensaje con los jugadores encarcelados y sus tiradas en la cárcel
                mensaje = mensaje.concat("[" + avatar.getJugador().getNombre() + "," + avatar.getJugador().getTiradasCarcel() + "]");
            }
        }
        if(this.getTipo().equals("Especial") && this.getNombre().equals("Parking")) {
            mensaje = mensaje.concat("[");
            for(Avatar avatar:avatares){ //Concatenamos el mensaje con los jugadores en el parking
                mensaje = mensaje.concat(avatar.getJugador().getNombre() + ", ");
            }
            mensaje = mensaje.concat("]");
        }
        return mensaje;
    }

    /*Método para mostrar información sobre una casilla.
    * Devuelve una cadena con información específica de cada tipo de casilla.*/
    public String infoCasilla() {
        String mensaje = new String();
        //Diferenciamos la informacion que vamos a imprimir con un switch en funcion del tipo de casilla q estemos evaluando
        switch(this.getTipo()){
            case "Impuesto":
                //en caso de que sea una casilla de impuesto imprimimos su tipo y el impuesto a pagar
                mensaje = "{\n\tTipo: " + this.getTipo() +
                          "\n\tA pagar: " + this.getImpuesto() +
                          "\n}";
                break;
            case "Especial":
                // en caso de que sea de tipo especial diferenciamos entre las distintas casillas especiales
                switch(this.getNombre()){
                    case "Salida":
                        //en la salida printeamos el valor q se te suma al pasar por ella
                        mensaje = "{\n\tValor al pasar:" + this.getValor() +
                                  "\n}";
                        break;
                    case "Carcel":
                        // para la carcel imprimimos el impuesto para salir de la carcel y los jugadores que hay en ella
                        mensaje = "{\n\tSalir: " + IMPUESTO_CARCEL +
                                    "\n\tJugadores: " + this.ListaJugadores(this.avatares) +
                                    "\n}";
                        break;
                    case "Parking":
                        // para el parking imprimimos el bote acumulado y los jugadores que hay en el parking
                        mensaje = "{\n\tBote: " + this.getValor() +
                                  "\n\tJugadores: " + this.ListaJugadores(this.avatares) +
                                  "\n}";
                        break;
                }
                break;
            case "Solar":
                // en caso de que sea una casilla solar imprimimos su tipo, grupo, propietario, valor, alquiler y demas valores asociados a las mejoras
                //en caso de que el propietario sea la banca no imprimimos su nombre
                if(this.getDuenho().getNombre().equals("banca")) {
                    mensaje = "{\n\tTipo: " + this.getTipo() +
                            "\n\tGrupo: " + this.getGrupo() +
                            "\n\tValor:" + this.getValor() +
                            "\n\tAlquiler:" + this.getImpuesto() +
                            "\n\tValor hotel:" +
                            "\n\tValor casa:" +
                            "\n\tValor piscina:" +
                            "\n\tValor pista de deporte:" +
                            "\n\tAlquiler casa:" +
                            "\n\tAlquiler hotel:" +
                            "\n}";
                }
                else{
                    mensaje = "{\n\tTipo: " + this.getTipo() +
                            "\n\tGrupo: " + this.getGrupo() +
                            "\n\tPropietario:" + this.getDuenho().getNombre()+
                            "\n\tValor:" + this.getValor() +
                            "\n\tAlquiler:" + this.getImpuesto() +
                            "\n\tValor hotel:" +
                            "\n\tValor casa:" +
                            "\n\tValor piscina:" +
                            "\n\tValor pista de deporte:" +
                            "\n\tAlquiler casa:" +
                            "\n\tAlquiler hotel:" +
                            "\n}";
                }
                break;
            case "Transporte": case "Servicios":
                // en caso de que sea una casilla de transporte o servicio imprimimos su tipo, propietario, valor y alquiler
                if(!this.getDuenho().getNombre().equals("banca")) {
                    mensaje = "{\n\tTipo: " + this.getTipo() +
                            "\n\tPropietario:" + this.getDuenho().getNombre() +
                            "\n\tValor:" + this.getValor() +
                            "\n\tAlquiler:" + this.getImpuesto() +
                            "\n}";
                }
                else{
                    mensaje= "{\n\tTipo: " + this.getTipo() +
                             "\n\tValor:" + this.getValor() +
                             "\n\tAlquiler:" + this.getImpuesto() +
                             "\n}";
                }
                break;
        }
        return mensaje;
    }

    /* Método para mostrar información de una casilla en venta.
     * Valor devuelto: texto con esa información.
     */
    public String casEnVenta() {
        String mensaje = new String(); //Reservamos memoria para el String
        if(this.getDuenho().getFortuna() == FORTUNA_BANCA){ //Si tiene el dueño tiene fortuna infinita, entonces es la banca
            switch(this.getTipo()){ //Obtenemos un tipo de casilla en venta y la imprimimos
                case "Solar":
                    mensaje = "{\n\tNombre:" + this.getNombre() +
                              "\n\tTipo: " + this.getTipo() +
                              "\n\tGrupo: " + this.getGrupo() +
                              "\n\tValor:" + this.getValor() +
                              "\n}";
                    break;
                case "Transporte": case "Servicios":
                    mensaje= "{\n\tNombre:"+ this.getNombre()+
                             "\n\tTipo: " + this.getTipo() +
                             "\n\tValor:" + this.getValor() +
                             "\n}";
                    break;
            }
            return mensaje;
        }
        return null;
    }

    //Método equals para comparar dos casillas (se consideran iguales si tienen el mismo nombre y posición).
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Casilla casilla = (Casilla) obj;
        return (nombre == casilla.nombre) && (posicion == casilla.posicion);
    }

    //Método para pagar el alquiler/impuesto de una casilla. Parámetros:
    // - Dueño de la casilla.
    // - Jugador moroso que debe pagar el alquiler/impuesto.
    public void pagarDeudas(Jugador duenho, Jugador moroso, Casilla casilla, int valorTirada) {
        switch (casilla.getTipo()) {
            case "Solar":
                moroso.sumarFortuna(-this.getImpuesto()); //El moroso resta su fortuna para pagar
                moroso.sumarGastos(this.getImpuesto()); //El moroso suma sus gastos por el pago realizado
                duenho.sumarFortuna(this.getImpuesto()); //El dueño suma su fortuna al recibir el pago
                break;

            case "Transporte":
                moroso.sumarFortuna(-contarCasillas(duenho,"Transporte") * casilla.getImpuesto());
                moroso.sumarGastos(contarCasillas(duenho,"Transporte") * casilla.getImpuesto());
                duenho.sumarFortuna(contarCasillas(duenho,"Transporte") * casilla.getImpuesto());
                break;

            case "Servicios":
                int numCasillas = contarCasillas(duenho,"Servicios");
                if(numCasillas==1){ //Si el dueño tiene un servicio se paga 4 veces la tirada por el impuesto
                    moroso.sumarFortuna(-4* valorTirada * casilla.getImpuesto());
                    moroso.sumarGastos(4* valorTirada * casilla.getImpuesto());
                    duenho.sumarFortuna(4* valorTirada * casilla.getImpuesto());
                }else if(numCasillas==2) { //Si el dueño tiene dos servicios se paga 10 veces la tirada por el impuesto
                    moroso.sumarFortuna(-10 * valorTirada * casilla.getImpuesto());
                    moroso.sumarGastos(10* valorTirada * casilla.getImpuesto());
                    duenho.sumarFortuna(10 * valorTirada * casilla.getImpuesto());
                }
                break;

        }

    }

}
