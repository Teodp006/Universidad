package monopoly;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import partida.*;

import static monopoly.Valor.FORTUNA_BANCA;
import static monopoly.Valor.IMPUESTO_CARCEL;

public class Menu {

    //Atributos
    private ArrayList<Jugador> jugadores; //Jugadores de la partida.
    private ArrayList<Avatar> avatares; //Avatares en la partida.
    private int turno = 0; //Índice correspondiente a la posición en el arrayList del jugador (y el avatar) que tienen el turno
    private int lanzamientos; //Variable para contar el número de lanzamientos de un jugador en un turno.
    private Tablero tablero; //Tablero en el que se juega.
    private Dado dado1; //Dos dados para lanzar y avanzar casillas.
    private Dado dado2;
    private Jugador banca; //El jugador banca.
    private boolean tirado; //Booleano para comprobar si el jugador que tiene el turno ha tirado o no.
    private boolean solvente; //Booleano para comprobar si el jugador que tiene el turno es solvente, es decir, si ha pagado sus deudas.

    //Constructor
    public Menu(ArrayList<String> listaComandos) {
        iniciarPartida();
        for (String comando : listaComandos) {
            analizarComando(comando);
        }
    }
    // Método para inciar una partida: crea los jugadores y avatares.
    private void iniciarPartida() {
        jugadores = new ArrayList<Jugador>();
        this.banca = new Jugador();
        tablero = new Tablero(this.banca);
        this.banca.setFortuna(FORTUNA_BANCA);
        this.banca.setPropiedades(this.tablero.propiedadesBanca());
        avatares = new ArrayList<Avatar>();
        dado1 = new Dado();
        dado2 = new Dado();
        tirado = false;
        solvente = true;
        lanzamientos = 0;
    }
    // setters y getters
    private ArrayList<Jugador> getJugadores() {
        return jugadores;
    }
    private ArrayList<Avatar> getAvatares() {
        return avatares;
    }
    private int getTurno() {
        return turno;
    }
    private int getLanzamientos(){
        return lanzamientos;
    }
    public Tablero getTablero() {
        return tablero;
    }
    private Dado getDado1() {
        return dado1;
    }
    private Dado getDado2() {
        return dado2;
    }
    private Jugador getBanca() {
        return banca;
    }
    private boolean getTirado() {
        return tirado;
    }
    private boolean getSolvente() {
        return solvente;
    }
    private void setJugadores(ArrayList<Jugador> jugadores) {
        this.jugadores = jugadores;
    }
    private void setAvatares(ArrayList<Avatar> avatares) {
        this.avatares = avatares;
    }
    private void setTurno(int turno) {
        this.turno = turno;
    }
    private void setLanzamientos(int lanzamientos){
        this.lanzamientos = lanzamientos;
    }
    private void setTablero(Tablero tablero) {
        this.tablero = tablero;
    }
    private void setDado1(Dado dado1) {
        this.dado1 = dado1;
    }
    private void setDado2(Dado dado2) {
        this.dado2 = dado2;
    }
    private void setBanca(Jugador banca) {
        this.banca = banca;
    }
    private void setTirado(boolean tirado) {
        this.tirado = tirado;
    }
    private void setSolvente(boolean solvente) {
        this.solvente = solvente;
    }
    // Fin setters y getters
    /*Método que interpreta el comando introducido y toma la accion correspondiente.
    * Parámetro: cadena de caracteres (el comando).
    */
    public void analizarComando(String comando) {
        System.out.println(">>> " + comando);
        //partimos el string del comando entero en sus diferentes componentes
        String[] partes = comando.split(" ");
        //distinguimos mediante el switch entre los diferentes comandos existentes.
        switch (partes[0]){
            case "crear":
                //distinguimos los diferentes casos del comando crear
                switch (partes[1]){
                    case "jugador":
                        //verificamos q el numero de jugadores es menor al numero maximo del juego
                        if (jugadores.size() >= 4) {
                            System.out.println("No se pueden crear más jugadores. El número máximo es 4.\n");
                            return;
                        }
                        // recorremos la lista de jugaodres para revisar q no tengamos el mismo nombre ya guardado
                        for(Jugador jugador: jugadores){
                            if(jugador.getNombre().equals(partes[2])){
                                System.out.println("El nombre de jugador " + partes[2] + " ya está en uso. Elija otro.\n");
                                return;
                            }
                        }
                        // comprobamos q la figura pertenezca a las disponibles y q no esta ya escogida
                        if(partes[3].equals("coche") || partes[3].equals("pelota") || partes[3].equals("sombrero") || partes[3].equals("esfinge")){
                            for(Jugador jugador :jugadores){
                                if(jugador.getAvatar().getTipo().equals(partes[3])){
                                    System.out.println("La figura " + jugador.getAvatar().getTipo() + " ya esta en uso. Elija otro\n");
                                    return;
                                }
                            }
                            Jugador jugador = new Jugador(partes[2], partes[3],tablero.getInicio(), avatares);
                            jugadores.add(jugador);
                        }
                        else{
                            System.out.println("El avatar " + partes[3] + " no existe. Los avatares disponibles son: coche, pelota, sombrero y esfinge.\n");
                            return;
                        }
                        break;
                }
                break;

            case "jugador":
                //llamamos al metodo q nos da el jugador que tiene el turno actualmente
                descJugador(comando);
                break;

            case "listar":
                //diferenciamos entre los diferentes casos del comando listar
                switch(partes[1]){
                    case "jugadores":
                        //llamamos al metodo q lista los jugadores
                        listarJugadores();
                        break;
                    case "enventa":
                        //llamamos al metodo q lista las casillas en venta
                        listarVenta();
                        break;
                }
                break;
                case "lanzar":
                    //comprobamos si el comando es lanzar dados
                    //comprobamos si el jugador ya ha tirado o no y si el jugador esta en la carcel
                    if(!tirado && !jugadores.get(turno).getenCarcel()) {
                        //si el comando tiene 3 partes se han forzado los dados
                        if (partes.length == 3) {
                            try {
                                String[] partes2 = partes[2].split("\\+");
                                lanzarDadosForzados(Integer.parseInt(partes2[0]), Integer.parseInt(partes2[1]));

                            } catch (NumberFormatException e) {
                                System.out.println("Error en el formato de los dados. Deben ser números enteros separados por '+'.\n");
                                tirado = false;
                            }
                        }
                        //si el comando tiene 2 partes se lanzan los dados obteniendo numeros aleatorios
                        if (partes.length == 2) {
                            if (partes[1].equals("dados")) {
                                lanzarDados();
                            }
                        }
                    // comprobamos si el jugador esta en la carcel y si no ha tirado aun para q pueda lanzar los dados para intentar salir sin pagar
                    }else if(!tirado && jugadores.get(turno).getenCarcel()){
                        System.out.println("El jugador " + jugadores.get(turno).getNombre() + " está en la carcel \n");
                        //si el comando tiene 3 partes se han forzado los dados
                        if (partes.length == 3) {
                            try {
                                String[] partes2 = partes[2].split("\\+");
                                lanzarDadosForzados(Integer.parseInt(partes2[0]), Integer.parseInt(partes2[1]));

                            } catch (NumberFormatException e) {
                                System.out.println("Error en el formato de los dados. Deben ser números enteros separados por '+'.\n");
                                tirado = false;
                            }
                        }
                        //si el comando tiene 2 partes se lanzan los dados obteniendo numeros aleatorios
                        if (partes.length == 2) {
                            if (partes[1].equals("dados")) {
                                lanzarDados();
                            }
                        }
                    }
                    else{
                        System.out.println("El jugador " + jugadores.get(turno).getNombre() + " ya ha tirado los dados este turno.\n");
                    }
                    //printeamos el tablero para comprobar como han quedado las posiciones de los jugadores tras la tirada
                    System.out.println(tablero);
                break;
            case "acabar":
                //distinguimos si el comando es acabar turno y llamamos al metodo correspondiente
                acabarTurno();
                //printeamos el jugador que tiene el turno ahora
                System.out.println("El jugador actual es " + jugadores.get(turno).getNombre() + ".\n");
                break;
            case "salir":
                //comprobamos si el comando es salir carcel y llamamos al metodo correspondiente en caso de que nuestro jugador este en la carcel
                if(jugadores.get(turno).getenCarcel()){
                    salirCarcel();
                }
                else{
                    System.out.println("El jugador " + jugadores.get(turno).getNombre() + " no está en la carcel.\n");
                }
                break;
            case "describir":
                //distinguimos entre los diferentes casos del comando describir
                switch(partes[1]){
                    case "jugador":
                        //llamamos al metodo q describe un jugador
                        descJugador(comando);
                        break;
                    default:
                        //llamamos al metodo q describe una casilla
                        descCasilla(partes[1]);
                        break;
                }
                break;
            case "comprar":
                //comprobamos si el comando es comprar casilla y si tiene al menos 2 partes para q pueda hacer bien la ejecucion
                if(partes.length != 2){
                    System.out.println("El comando 'comprar' debe ir seguido del nombre de la casilla a comprar.\n");
                    break;
                }
                //llamamos al metodo para comprar la casilla
                comprar(partes[1]);
                break;
            case "ver":
                //comprobamos si el comando es ver tablero y printeamos el tablero
                System.out.println(tablero);
                break;
            default:
                System.out.println("Ese comando no existe\n");
                break;
        }
    }

    /*Método que realiza las acciones asociadas al comando 'describir jugador'.
    * Parámetro: comando introducido
     */
    private void descJugador(String comando) {
        String partes[] = comando.split(" ");
        //partimos el comando en sus diferentes partes y comprobamos si tiene 1 o 3 partes
        //si tiene 1 parte decimos el jugador que tiene el turno
        if(partes.length == 1) {
            Jugador jugador = jugadores.get(turno);
            String mensaje = "{\n\tnombre: " + jugador.getNombre() + ",\n\tavatar: " + jugador.getAvatar();
            System.out.println(mensaje + "\n}\n");
        }
        //si tiene 3 partes buscamos el jugador con el nombre indicado y mostramos su informacion
        else if(partes.length == 3) {
            String nombreJugador = partes[2];
            //verificamos q exista dicho jugador dentro de nuestra lista de jugadores y printeamos su informacion
            for (Jugador jugador : jugadores) {
                if (jugador.getNombre().equals(nombreJugador)) {
                    String mensaje = "{\n\tnombre: " + jugador.getNombre() +
                            ",\n\tavatar: " + jugador.getAvatar() +
                            ",\n\tfortuna: " + (int) jugador.getFortuna();
                    if (!jugador.getPropiedades().isEmpty()) {
                        mensaje += ",\n\tpropiedades: [";
                        for (Casilla casilla : jugador.getPropiedades()) {
                            mensaje += casilla.getNombre();
                            if (casilla != jugador.getPropiedades().getLast()) {
                                mensaje += ", ";
                            }
                        }
                        mensaje += "]";
                    }
                    System.out.println(mensaje + "\n}\n");
                    return;
                }
            }
            System.out.println("El jugador " + nombreJugador + " no existe en la partida.\n");
            return;
        }
    }

    /*Método que realiza las acciones asociadas al comando 'describir avatar'.
    * Parámetro: id del avatar a describir.
    */
    private void descAvatar(String ID) {
        for(Jugador jugador: jugadores){
            Avatar avatar = jugador.getAvatar();
            if(avatar.getId().equals(ID)){
                descJugador("descibir jugador"+ " " + jugador.getNombre());
                return;
            }
        }
    }


    /* Método que realiza las acciones asociadas al comando 'describir nombre_casilla'.
    * Parámetros: nombre de la casilla a describir.
    */
    private void descCasilla(String nombre) {
        //buscamos la casilla en el tablero
        Casilla casilla= tablero.buscarCasilla(nombre);
        //verificamos q sea diferente de null para printear su informacion
        if(casilla != null) {
            System.out.println(casilla.infoCasilla());
        }
        //en el caso contrario informamos de que no existe dicha casilla
        else{
            System.out.println("La casilla " + nombre + " no existe en el tablero.\n");
        }
    }

    //Método que ejecuta todas las acciones relacionadas con el comando 'lanzar dados'.
    private void lanzarDados() {
        //verificamos q haya jugadores en la partida
        if(jugadores.isEmpty()){
            System.out.println("No hay jugadores en la partida. No se pueden lanzar los dados.\n");
            return;
        }
        //realizamos la tirada de ambos dados y llamamos al metodo para poder avanzar las casillas correspondientes
        dado1.hacerTirada();
        dado2.hacerTirada();
        realizarTirada(dado1, dado2, jugadores.get(turno));
    }
    //Método que ejecuta todas las acciones relacionadas con el comando 'lanzar dados' con valores forzados.
    private void lanzarDadosForzados(int a,int b) {
        //verificamos q haya jugadores en la partida
        if(jugadores.isEmpty()){
            System.out.println("No hay jugadores en la partida. No se pueden lanzar los dados.\n");
            return;
        }
        //realizamos la tirada de ambos dados con los valores forzados y llamamos al metodo para poder avanzar las casillas correspondientes
        dado1.hacerTirada(a);
        dado2.hacerTirada(b);
        realizarTirada(dado1, dado2, jugadores.get(turno));
    }

    private void realizarTirada(Dado d1, Dado d2, Jugador jugador) {
        tirado = false;
            //comprobamos q el jugador no haya tirado ya y no este en la carcel
            if (!tirado && !jugador.getenCarcel()) {
                //movemos el avatar del jugador la suma de ambos dados
                jugador.getAvatar().moverAvatar(tablero.getPosiciones(), dado1.getValor() + dado2.getValor());
                //verificamos si se han sacado dobles o no y se actualiza el contador de lanzamientos
                tirado = !(dado1.sonDobles(dado2));
                if (tirado == false) {
                    lanzamientos += 1;
                }
                //si se han sacado dobles 3 veces seguidas el jugador va a la carcel
                if (lanzamientos == 3 && dado1.sonDobles(dado2)) {
                    System.out.println("El jugador " + jugadores.get(turno).getNombre() + " ha tirado dobles tres veces seguidas y va a la carcel.\n");
                    jugadores.get(turno).encarcelar(tablero.getPosiciones());
                    acabarTurno();
                }
            // comprobamos si el jugador no ha tirado ya y si esta en la carcel
            }else if(!tirado && jugador.getenCarcel()){
                //actualizamos las tiradas en la carcel del jugador
                jugador.setTiradasCarcel(jugadores.get(turno).getTiradasCarcel()+1);
                //verificamos si son dobles para comprobar si sale de la carcel y como ha sacado dobles reseteamos sus tiradas en la carcel y le dejamos q pueda mover su avatar y pueda volver a tirar
                if(dado1.sonDobles(dado2)){
                    System.out.println("El jugador " + jugadores.get(turno).getNombre() + " ha sacado dobles y sale de la carcel.\n");
                    jugador.setEnCarcel(false);
                    jugador.setTiradasCarcel(0);
                    jugador.getAvatar().moverAvatar(tablero.getPosiciones(), dado1.getValor() + dado2.getValor());
                    tirado = false;
                }
                //si no ha sacado dobles y ya ha tirado 3 veces en la carcel paga el impuesto y sale de la carcel moviendo su avatar
                if(!dado1.sonDobles(dado2) && jugadores.get(turno).getTiradasCarcel()>2){
                    salirCarcel();
                    jugador.getAvatar().moverAvatar(tablero.getPosiciones(), dado1.getValor() + dado2.getValor());
                }
            }
            else{
                System.out.println("El jugador " + jugador.getNombre() + " ya ha tirado los dados este turno.\n");
            }
    }

    /*Método que ejecuta todas las acciones realizadas con el comando 'comprar nombre_casilla'.
    * Parámetro: cadena de caracteres con el nombre de la casilla.
     */
    private void comprar(String nombre) {
        //buscamos la casilla en el tablero y obtenemos el jugador que tiene el turno
        Casilla casilla = tablero.encontrar_casilla(nombre);
        Jugador jugador = jugadores.get(turno);
        //verificamos q la casilla no sea null para proceder a la compra
        if(casilla!=null) {
            //verificamos q el dueño de la casilla sea la banca y q el jugador este en la casilla para poder comprarla
            if(casilla.getDuenho().equals(banca)) {
                if(jugadores.get(turno).getAvatar().getLugar() != casilla){
                    System.out.println("El jugador " + jugador.getNombre() + " no está en la casilla " + nombre + " y no puede comprarla.\n");
                }
                else {
                    //realizamos la compra de la casilla
                    casilla.comprarCasilla(jugador, banca);
                    System.out.println("El jugador " + jugadores.get(turno).getNombre() + " ha comprado la casilla " + nombre + ".\n");
                }
            }
            //si la casilla no pertenece a la banca informamos de su dueño
            else{
                System.out.println("La casilla " + nombre + " le pertenece a " + casilla.getDuenho().getNombre() + "\n");
            }
        }
        //en caso de que no este en el tablero informamos de que no existe dicha casilla
        else{
            System.out.println("La casilla " + nombre + " no existe en el tablero.\n");
        }
    }

    //Método que ejecuta todas las acciones relacionadas con el comando 'salir carcel'.
    private void salirCarcel() {
        //sacamos el jugador q tiene el turno y realizamos las acciones para salir de la carcel pagando el impuesto
        Jugador jugador = jugadores.get(turno);
        jugador.setEnCarcel(false);
        jugador.sumarGastos(IMPUESTO_CARCEL);
        jugador.sumarFortuna(-IMPUESTO_CARCEL);
        System.out.println(jugador.getNombre()+ " paga " + IMPUESTO_CARCEL + " y sale de la carcel. Puede lanzar los dados\n");
    }

    // Método que realiza las acciones asociadas al comando 'listar enventa'.
    private void listarVenta() {
        //recorremos todas las casillas del tablero y printeamos las que esten en venta (aquellas cuyo dueño sea la banca)
        for(ArrayList<Casilla> lado: tablero.getPosiciones()){
            for(Casilla casilla : lado) {
                if(casilla.casEnVenta()!=null){
                    System.out.println(casilla.casEnVenta());
                }
            }
        }
    }

    // Método que realiza las acciones asociadas al comando 'listar jugadores'.
    private void listarJugadores() {
        System.out.println("{\n");
        int i=0;
        // recorremos la lista de jugadores con un for each para printear su informacion
        for (Jugador jugador : jugadores) {
            System.out.println("\tnombre: " + jugador.getNombre() + ",\n\tavatar: " + jugador.getAvatar().getTipo() + ",\n\tfortuna: " + (int)jugador.getFortuna());
            //verificamos si el jugador tiene propiedades para printearlas
            if(!jugador.getPropiedades().isEmpty()){
                System.out.print("\tpropiedades: [");
                int j=0;
                //recorremos la lista de propiedades del jugador para printearlas
                for(Casilla casilla: jugador.getPropiedades()){
                    System.out.print(casilla.getNombre());
                    if(j<jugador.getPropiedades().size()-1){
                        System.out.print(",");
                        j++;
                    }
                }
                System.out.print("]\n\t");
            }
            if(i<jugadores.size()-1){
                System.out.println(",\n");
                i++;
            }
        }
        System.out.println("}\n");
    }

    // Método que realiza las acciones asociadas al comando 'listar avatares'.
    private void listarAvatares() {
    }

    // Método que realiza las acciones asociadas al comando 'acabar turno'.
    private void acabarTurno() {
        // actualizamos el turno al siguiente jugador
        int i= jugadores.size();
        turno=(turno+1)%i;
        tirado=false;
        lanzamientos=0;

    }
}



