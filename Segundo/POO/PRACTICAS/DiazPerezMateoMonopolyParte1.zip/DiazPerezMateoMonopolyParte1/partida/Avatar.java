package partida;

import monopoly.*;

import java.util.ArrayList;
import java.util.Random;


public class Avatar {

    //Atributos
    private String id; //Identificador: una letra generada aleatoriamente.
    private String tipo; //Sombrero, Esfinge, Pelota, Coche
    private Jugador jugador; //Un jugador al que pertenece ese avatar.
    private Casilla lugar; //Los avatares se sitúan en casillas del tablero.

    //Constructor vacío
    public Avatar() {
    }

    /*Constructor principal. Requiere éstos parámetros:
     * Tipo del avatar, jugador al que pertenece, lugar en el que estará ubicado, y un arraylist con los
     * avatares creados (usado para crear un ID distinto del de los demás avatares).
     */
    public Avatar(String tipo, Jugador jugador, Casilla lugar, ArrayList<Avatar> avCreados) {
        this.jugador = jugador;
        this.lugar = lugar;
        lugar.anhadirAvatar(this);
        this.tipo = tipo;
        if(avCreados == null){
            avCreados = new ArrayList<Avatar>();
        }
        avCreados.add(this);
        generarId(avCreados);
    }

    //Getters y setters

    public String getId() {
        return id;
    }

    public Jugador getJugador() {
        return jugador;
    }

    public String getTipo() {
        return tipo;
    }

    public Casilla getLugar() {
        return lugar;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setJugador(Jugador jugador) {
        this.jugador = jugador;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setLugar(Casilla lugar) {
        this.lugar = lugar;
    }


    //A continuación, tenemos otros métodos útiles para el desarrollo del juego.
    /*Método que permite mover a un avatar a una casilla concreta. Parámetros:
     * - Un array con las casillas del tablero. Se trata de un arrayList de arrayList de casillas (uno por lado).
     * - Un entero que indica el numero de casillas a moverse (será el valor sacado en la tirada de los dados).
     * EN ESTA VERSIÓN SUPONEMOS QUE valorTirada siempre es positivo.
     */
    public void moverAvatar(ArrayList<ArrayList<Casilla>> casillas, int valorTirada) {
        /*Buscamos la localizacion del lugar donde está nuestro Avatar, será un casillas[p1][p2]*/
        // Primero el Lado sur del talbero Casillas[0
        int p1 = 0, p2 = 0;
        if((casillas.getFirst()).contains(this.getLugar())){
            // Buscamos su posición dentro de la zona
            p2 = casillas.getFirst().indexOf(this.getLugar());
        }
        // Luego el Lado Oeste Casillas[1]
        else if((casillas.get(1)).contains(this.getLugar())){
            // Buscamos su posición dentro de la zona
            p2 = casillas.get(1).indexOf(this.getLugar());
            p1 = 1;
        }
        // Luego el Lado Norte Casillas[2]
        else if((casillas.get(2)).contains(this.getLugar())){
            // Buscamos su posición dentro de la zona
            p2 = casillas.get(2).indexOf(this.getLugar());
            p1 = 2;
        }
        // Luego el Lado Este Casillas[3]
        else if((casillas.get(3)).contains(this.getLugar())){
            // Buscamos su posición dentro de la zona
            p2 = casillas.get(3).indexOf(this.getLugar());
            p1 = 3;
        }
        // Guardamos la casilla de donde sale el Avatar
        Casilla origen = casillas.get(p1).get(p2);
        // Eliminanos el avatar de la casilla actual para poder moverlo a la nueva
        origen.getAvatares().remove(this);
        //Compruebo que al sumar valorTirada a la casilla no me pase de una zona a la siguiente
        if(p2+valorTirada>casillas.get(p1).size()-1){ // Si su posicion dentro de Lado más la tirada es mayor que el tamaño del lado
            p2 = valorTirada - (casillas.get(p1).size() - p2); // La nueva posicion dentro del siguinte Lado será [valor tirada - (casillas que faltan en la zona actual)]
            if(p1 < 3) { // Avanzamos a la siguiente zona
                p1 += 1;
            }
            else { // Si estamos en la última, volvemos a la primera zona
                p1 = 0;
                // Sumamos una vuelta al jugador
                this.getJugador().setVueltas(this.getJugador().getVueltas()+1);
                // Comprovamos que la primera vez se pasa de Salida (ESTE) a Solar1 (SUR) pero no se debe sumar la fortuna, solo las
                // siguientes veces
                if(this.getJugador().getVueltas()>0){
                    this.getJugador().sumarFortuna(Valor.SUMA_VUELTA);
                }
            }
        }
        else{ //Sino, simplemente sumamos las casilla en la zona que estamos
            p2 += valorTirada;
        }
        // Comprobamos que no se pase dos zonas en una tirada NuevoLado[NuevaPosicion] > Tamaño NuevoLado
        if(p2>casillas.get(p1).size()-1){
            p2 = p2 - casillas.get(p1).size(); // En la siguiente zona avanzamos las que nos faltan

            if(p1 < 3) { // Avanzamos a la siguiente zona
                p1 += 1;
            }
            else { // Si estamos en la última, volvemos a la primera zona
                p1 = 0;
                // Sumamos una vuelta al jugador
                this.getJugador().setVueltas(this.getJugador().getVueltas()+1);
                // Aqui no hace falta verificar porque la primera vez solo se salta una Zona
                this.getJugador().sumarFortuna(Valor.SUMA_VUELTA);
            }
        }
        // Ahora p1 y p2 indican la casilla destino
        Casilla destino = casillas.get(p1).get(p2);
        // Guardamos el jugador banca para poder saber si la casilla a la que nos movesmos tiene un alquiler o impuesto a pagar
        Jugador banca = casillas.get(3).getLast().getDuenho();
        // Añadimos el avatar a la casilla destino
        destino.getAvatares().add(this);
        // Ahora mostramos los mensajes correspondientes según la casilla destino
        if(destino.getNombre().equals("IrCarcel")){
            // Si caes en la casilla IrCarcel, automaticamente hay que encarcelar al jugador
            this.getJugador().encarcelar(casillas);
            // ELiminarlo de IrCarcel para que no se duplique
            destino.eliminarAvatar(this);
            // Imprimir un mensaje que indique que el jugador ha sido encarcelado
            System.out.println("El jugador " + this.getJugador().getNombre() + " ha avanzado " + valorTirada + " posiciones desde la casilla " + origen.getNombre() + "hasta la casilla IrCarcel. El avatar se coloca en la casilla de Cárcel");
            return;
        }
        // Mensaje para cuando caes en el Parking, si hay dinero a cobrar lo obtienes y se imprime por pantalla, si no simplemente se dice que te mueves a esa casilla
        else if(destino.getNombre().equals("Parking")){
            System.out.println(
                "El avatar " + this.getId() + " avanza " + valorTirada + " posiciones, desde la casilla " + origen.getNombre() + " hasta la casilla " + destino.getNombre() + ". El jugador " + this.getJugador().getNombre() +
                (destino.getValor() > 0 ? " recibe " + destino.getValor() + "€": " no recibe nada"));
            if(destino.getValor() > 0){
                this.getJugador().sumarFortuna(destino.getValor());
                destino.setValor(0);
            }
        }
        // Mensaje para las casillas de impuesto, siempre hay que pagarle dinero a la banca y añadirlo al parking
        else if(destino.getTipo().equals("Impuesto")){
            System.out.println("El avatar " + this.getId() + " avanza " + valorTirada + " posiciones, desde la casilla " + origen.getNombre() + " hasta la casilla " + destino.getNombre() + ". El jugador " + this.getJugador().getNombre() +" paga " + destino.getImpuesto() + "€ de impuesto que se depositan en el Parking.");
            if(destino.evaluarCasilla(this.getJugador(), banca, 0)){
                destino.pagarDeudas(banca, this.jugador,destino,valorTirada);
                // La casilla del Parking es la última del lado Oeste
                Casilla parking = casillas.get(1).getLast();
                parking.sumarValor(destino.getImpuesto());
            }
            else{
                // Este es el caso en el que el impuesto supera la fortuna del jugador
                System.out.println("BANCARROTA DE " + this.getJugador().getNombre()); //Hay que programar la bancarrota
            }
        }
        else if(destino.getTipo().equals("Solar") || destino.getTipo().equals("Transporte") || destino.getTipo().equals("Servicios")){
            // Mensaje para las casillas que pueden tener dueño y por tanto alquiler a pagar (Solo si el duenho no es el propio jugador)
            if(!destino.getDuenho().equals(banca) && !destino.getDuenho().equals(this.getJugador())){
                // Si la casilla tiene dueño y se puede pagar el alquiler hay que poner el precio a pagar
                if(destino.evaluarCasilla(this.getJugador(), destino.getDuenho(), 0)){
                    if(destino.getTipo().equals("Solar")) {
                        System.out.println("El avatar " + this.getId() + " avanza " + valorTirada + " posiciones, desde la casilla " + origen.getNombre() + " hasta la casilla " + destino.getNombre() + ". Se han pagado " + destino.getImpuesto() + "€ de alquiler al jugador " + destino.getDuenho().getNombre() + ".");
                    } else if(destino.getTipo().equals("Transporte")) {
                        System.out.println("El avatar " + this.getId() + " avanza " + valorTirada + " posiciones, desde la casilla " + origen.getNombre() + " hasta la casilla " + destino.getNombre() + ". Se han pagado " + destino.contarCasillas(destino.getDuenho(),"Transporte") * destino.getImpuesto() + "€ de alquiler al jugador " + destino.getDuenho().getNombre() + ".");
                    } else if(destino.getTipo().equals("Servicios")) {
                        if(destino.contarCasillas(destino.getDuenho(),"Servicios") == 1){
                            System.out.println("El avatar " + this.getId() + " avanza " + valorTirada + " posiciones, desde la casilla " + origen.getNombre() + " hasta la casilla " + destino.getNombre() + ". Se han pagado " + (valorTirada * 4)* destino.getImpuesto() + "€ de alquiler al jugador " + destino.getDuenho().getNombre() + ".");
                        }
                        else{
                            System.out.println("El avatar " + this.getId() + " avanza " + valorTirada + " posiciones, desde la casilla " + origen.getNombre() + " hasta la casilla " + destino.getNombre() + ". Se han pagado " + (valorTirada * 10)* destino.getImpuesto() + "€ de alquiler al jugador " + destino.getDuenho().getNombre() + ".");
                        }
                    }
                    destino.pagarDeudas(destino.getDuenho(), this.jugador, destino, valorTirada);
                }
                // Si no se puede pagar el alquiler hay que indicar que el jugador cae en bancarrota
                else{
                    System.out.println("El avatar " + this.getId() + " avanza " + valorTirada + " posiciones, desde la casilla" + this.getJugador().getNombre() + " hasta la casilla " + destino.getNombre() + ". Se han intentado pagar " + destino.getImpuesto() + "€ de alquiler al jugador " + destino.getDuenho().getNombre() + ", pero el jugador no tiene suficiente dinero. " + this.getJugador() + " cae en Bancarrota." ); //Hay que programar la bancarrota
                }
            }
            // Mensaje para las casillas que no tienen dueño (la banca) o que el dueño es el propio jugador
            else if(destino.getDuenho().equals(banca)){
                System.out.println("El avatar " + this.getId() + " avanza " + valorTirada + " posiciones, desde la casilla " + origen.getNombre() + " hasta la casilla " + destino.getNombre() + ".");
            }
        }
        // Mensaje predeterminado para casillas con acciones sin programar por ahora como Suerte y Comunidad
        else{
            System.out.println("El avatar " + this.getId() + " avanza " + valorTirada + " posiciones, desde la casilla " + origen.getNombre() + " hasta la casilla " + destino.getNombre() + ".");
        }
        // Colocamos al avatar en la casilla destino
        this.setLugar(destino);
    }

    /*Método que permite generar un ID para un avatar. Sólo lo usamos en esta clase (por ello es privado).
     * El ID generado será una letra mayúscula. Parámetros:
     * - Un arraylist de los avatares ya creados, con el objetivo de evitar que se generen dos ID iguales.
     */
    private void generarId(ArrayList<Avatar> avCreados) {
        char i;
        Random rnd = new Random();
        //creamos un bucle do-while para generar un id aleatorio que no exista ya en el array de avatares creados
        do {
            i = (char)('A' + rnd.nextInt(26)); //Genera números desde 65 hasta 90

        } while (existeId(avCreados, i));
        //convertimos el valor char a String y lo asignamos al id del avatar
        avCreados.getLast().setId(String.valueOf(i));
        System.out.println("Id del Avatar: " + getId());
    }


    /*Método auxiliar para comprobar si un Id se encuentra en el Array de Avatares*/
    private boolean existeId(ArrayList<Avatar> avCreados, char i) {
        // Si hay más de un avatar creado, comprobamos si el id generado ya existe en alguno de ellos con un bucle for each
        if(avCreados.size()>1) {
            for (Avatar av : avCreados) {
                if (av != avCreados.getLast() && av.getId().equals(String.valueOf(i))) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    //sobreescribimos el metodo toString para que devuelva el id del avatar
    public String toString(){
        return id;
    }

}
