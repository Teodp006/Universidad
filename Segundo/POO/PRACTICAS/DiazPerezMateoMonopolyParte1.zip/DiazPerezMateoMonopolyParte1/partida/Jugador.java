package partida;

import java.util.ArrayList;
import monopoly.*;


public class Jugador {

    //Atributos:
    private String nombre; //Nombre del jugador
    private Avatar avatar; //Avatar que tiene en la partida.
    private float fortuna; //Dinero que posee.
    private float gastos; //Gastos realizados a lo largo del juego.
    private boolean enCarcel; //Será true si el jugador está en la carcel
    private int tiradasCarcel; //Cuando está en la carcel, contará las tiradas sin éxito que ha hecho allí para intentar salir (se usa para limitar el numero de intentos).
    private int vueltas; //Cuenta las vueltas dadas al tablero.
    private ArrayList<Casilla> propiedades; //Propiedades que posee el jugador.

    //Constructor vacío. Se usará para crear la banca.
    public Jugador() {
    }

    /*Constructor principal. Requiere parámetros:
    * Nombre del jugador, tipo del avatar que tendrá, casilla en la que empezará y ArrayList de
    * avatares creados (usado para dos propósitos: evitar que dos jugadores tengan el mismo nombre y
    * que dos avatares tengan mismo ID). Desde este constructor también se crea el avatar.
     */
    public Jugador(String nombre, String tipoAvatar, Casilla inicio, ArrayList<Avatar> avCreados) {
        this.nombre = nombre;
        this.avatar = new Avatar(tipoAvatar,this,inicio, avCreados);
        this.fortuna= Valor.FORTUNA_INICIAL;
        this.gastos=0;
        this.enCarcel= false;
        this.tiradasCarcel=0;
        this.vueltas=-1; //Empieza en -1 porque al salir de la salida ya le se suma una
        this.propiedades= new ArrayList<Casilla>();;
    }
    //Seters y geters
    public String getNombre(){
        return nombre;
    }
    public Avatar getAvatar(){
        return avatar;
    }
    public float getFortuna(){
        return fortuna;
    }
    public float getgastos(){
        return gastos;
    }
    public boolean getenCarcel(){
        return enCarcel;
    }
    public int getTiradasCarcel(){
        return tiradasCarcel;
    }
    public int getVueltas(){
        return vueltas;
    }
    public ArrayList<Casilla> getPropiedades(){
        return propiedades;
    }
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    public void setAvatar(Avatar avatar){ //Se comprueba que sea un avatar existente
        if(avatar.getTipo().equals("sombrero") || avatar.getTipo().equals("esfinge")
                || avatar.getTipo().equals("pelota") || avatar.getTipo().equals("coche")){
        this.avatar = avatar;
        }
    }
    public void setFortuna(float Fortuna){this.fortuna = Fortuna;}
    public void setGastos(float gastos){this.gastos= gastos;}
    public void setEnCarcel(Boolean enCarcel){
        this.enCarcel= enCarcel;
    }
    public void setTiradasCarcel(int tiradasCarcel){this.tiradasCarcel= tiradasCarcel;}
    public void setVueltas(int Vueltas){
        this.vueltas= Vueltas;
    }
    public void setPropiedades(ArrayList<Casilla> propiedades){this.propiedades= propiedades;}
    //Otros métodos:
    //Método para añadir una propiedad al jugador. Como parámetro, la casilla a añadir.
    public void anhadirPropiedad(Casilla casilla) {
        this.propiedades.add(casilla);
    }

    //Método para eliminar una propiedad del arraylist de propiedades de jugador.
    public void eliminarPropiedad(Casilla casilla) {
        this.propiedades.remove(casilla);
    }

    //Método para añadir fortuna a un jugador
    //Como parámetro se pide el valor a añadir. Si hay que restar fortuna, se pasaría un valor negativo.
    public void sumarFortuna(float valor) {
        this.fortuna +=valor;
    }

    //Método para sumar gastos a un jugador.
    //Parámetro: valor a añadir a los gastos del jugador (será el precio de un solar, impuestos pagados...).
    public void sumarGastos(float valor) {
        this.gastos += valor;
    }

    /*Método para establecer al jugador en la cárcel.
    * Se requiere disponer de las casillas del tablero para ello (por eso se pasan como parámetro).*/
    public void encarcelar(ArrayList<ArrayList<Casilla>> pos) {
        Casilla carcel = pos.get(1).get(0); //Casilla de la carcel.
        carcel.anhadirAvatar(avatar);//Coloca el avatar del jugador en la casilla de la carcel.
        this.avatar.getLugar().eliminarAvatar(avatar); //Elimina el avatar de la casilla en la que estaba.
        this.avatar.setLugar(carcel); //Actualiza la posición del avatar.
        this.enCarcel = true; //Indica que el jugador está en la carcel.
        this.tiradasCarcel = 0; //Resetea las tiradas en la carcel a 0.
    }

    //Reescritura del método equals para decir que 2 jugadores son el mismo si tienen el mismo nombre
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Jugador jugador = (Jugador) obj;
        return nombre.equals(jugador.nombre);
    }

    //Reescritura del método toString para imprimir a un Jugador
    @Override
    public String toString() {
        return "{\n\t" +
                "Nombre: " + nombre + "\n\t" +
                "Avatar: " + avatar.getId() +
                "\n\t}";
    }


}
