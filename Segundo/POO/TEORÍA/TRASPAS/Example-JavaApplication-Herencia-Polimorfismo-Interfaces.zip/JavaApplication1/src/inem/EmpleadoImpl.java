/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inem;

/**
 *
 * @author sepaj
 */
public class EmpleadoImpl implements Empleado {
    private String name;
    private String tipo;
    private int age;
    
    public EmpleadoImpl(String n, String t, int a) {
        this.name= n;
        this.tipo= t;
        this.age= a;
        System.out.println("Creado EmpleadoImpl");
    }
    
    public void setName(String n) {
        this.name= n;
    }
    
    public String getName() {
        return this.name;
    }

    public void setTipo(String t) {
        this.tipo= t;
    }
    
    public String getTipo() {
        return this.tipo;
    }

    public void setAge(int a) {
        this.age= a;
    }
    
    public int getAge() {
        return this.age;
    }
    
    public double sueldo() {
        if (this.tipo.equals("base"))
            return Empleado.super.getBase(1);
        else if (this.tipo.equals("publico"))
            return Empleado.super.getBase(2);
        else if (this.tipo.equals("privado"))
            return Empleado.super.getBase(3);
        else
            return -1;
    }
}
