/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inem;

/**
 *
 * @author sepaj
 */
public class Proyecto {
    String tipo;
    
    public Proyecto(String t) {
        this.tipo= t;
    }
    
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String t) {
        this.tipo= t;
    }

    @Override
    public String toString() {
        return "Proyecto de tipo "+this.tipo;
    }

}
